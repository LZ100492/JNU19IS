#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"cJSON.h"
#include <time.h>

void generateStudentsData(int count, struct Student* students);
void generateCoursesData(int count, struct Course* courses);
void generateStudentScoresData(int studentsCount, int coursesCount, struct StudentScore* studentScores, struct Student* students, struct Course* courses);

void saveStudentsData(cJSON* json, struct Student* students, int count, char fileName[]);
void saveCoursesData(cJSON* json, struct Course* courses, int count, char fileName[]);
void saveStudentScoresData(cJSON* json, struct StudentScore* studentScores, int count, char fileName[]);

int addStudent(struct Student* students, int* studentsCount, int addNumberID, char addName[], int addGender, int addAge, char addDepartment[]);
int addCourse(struct Course* courses, int* coursesCount, int addNumberID, char addName[], int addPreClass, int addScore);
int addStudentScores(struct Student* students, struct Course* courses, struct StudentScore* studentScores, int studentsCount, int addStudentNumberID, int addCoursesNumberID[], float addScore[], int addCoursesCount);

int findStudent(struct Student* students, int* idx, int studentNumberID, int studentsCount);
int findStudentWithName(struct Student* students, int* idx, char studentName[], int studentsCount);
int findCourse(struct Course* courses, int* idx, int courseNumberID, int coursesCount);
int findStudentScore(struct StudentScore* studentScores, int* idx, int studentNumberID, int studentsCount);

void sortStudents(struct Student* students, int studentsCount);
void sortCourses(struct Course* courses, int coursesCount);
void sortStudentScores(struct StudentScore* studentScores, int studentsCount);

int editStudentName(struct Student* students, int studentsCount, int editStudentNumberID, char newName[]);
int editStudentGender(struct Student* students, int studentsCount, int editStudentNumberID, int newGender);
int editStudentAge(struct Student* students, int studentsCount, int editStudentNumberID, int newAge);
int editStudentDepartment(struct Student* students, int studentsCount, int editStudentNumberID, char newDepartment[]);

int deleteStudent(struct Student* students, int* studentsCount, struct StudentScore* studentScores, int deleteStudentNumberID);


int random(int m);
float randomFloat(int m);
void generateStr(char* str, int isGenerateInt, int isGenerateBigCase, int strLen);

struct Student {
    int numberID;
    char* name[10];
    int gender;
    int age;
    char* department[10];
};

struct Course {
    int numberID;
    char* name[10];
    int preClass;
    int score;
};

struct StudentScore {
    int studentNumberID;
    int coursesCount;
    int* courseNumberID;
    float* score;
};

int main(void) {
    srand((unsigned)time(0));

    cJSON* jsonStudents = cJSON_CreateObject();
    cJSON* jsonCourses = cJSON_CreateObject();
    cJSON* jsonStudentScores = cJSON_CreateObject();

    int studentsCount = 1000;
    int coursesCount = 50;
    //int perStudentCoursesCount = 10;
    printf("����ѧ��������\n");
    scanf("%d", &studentsCount);
    printf("����γ�������\n");
    scanf("%d", &coursesCount);

    struct Student* students;
    students = (struct Student*)malloc(studentsCount * 2 * sizeof(struct Student));

    struct Course* courses;
    courses = (struct Course*)malloc(coursesCount * 2 * sizeof(struct Course));

    struct StudentScore* studentScores;
    studentScores = (struct StudentScore*)malloc(studentsCount * 2 * sizeof(struct StudentScore));

    printf("����Ϊ%d��ѧ����%d���γ����������Ϣ����Ϊ���Ƿ���γ������\n�����������ʼ\n", studentsCount, coursesCount);
    system("pause");

    generateStudentsData(studentsCount, students);
    generateCoursesData(coursesCount, courses);
    generateStudentScoresData(studentsCount, coursesCount, studentScores, students, courses);

    printf("��������������ϵͳ�������\n1.����ѧ�����γ�\n2.ɾ��ѧ����ѧ���ɼ���ͬ��ɾ����\n3.����ѧ����ѧ�������Ϣ\n4.����ѧ����Ϣ���ɼ���\n�����������ʼ\n");
    system("pause");

    while (1){
        char saveStr[10];
        printf("���롰SAVE�����б��棬����ֱ�ӻس������������\n");
        gets(saveStr);

        if (strcmp(saveStr, "SAVE") == 0) {
            break;
        }

        int flag = 0;
        printf("����\n1��������ѧ�����γ�\n2����ɾ��ѧ����ѧ���ɼ���ͬ��ɾ����\n3��������ѧ����ѧ�������Ϣ\n4��������ѧ����Ϣ���ɼ���\n");
        scanf("%d", &flag);

        switch (flag) {
            case 1:
                printf("����ѧ��������1�����ӿγ̣�����2\n");
                scanf("%d", &flag);
                if (flag == 1) {
                    int numberID = 0;
                    char name[12] = { 0 };
                    int gender = 0;
                    int age = 0;
                    char department[12] = { 0 };

                    printf("����ѧ��(�������6λ��)��\n");
                    scanf("%d", &numberID);
                    printf("����������\n");
                    scanf("%s", name);
                    printf("����%s���Ա���Ϊ1��ŮΪ0����\n", name);
                    scanf("%d", &gender);
                    printf("����%s�����䣺\n", name);
                    scanf("%d", &age);
                    printf("����%s��Ժϵ��\n", name);
                    scanf("%s", department);

                    if (addStudent(students, &studentsCount, numberID, name, gender, age, department)) {
                        printf("����ѧ���ɹ�\n");
                    }
                    else {
                        printf("����ѧ��ʧ��\n");
                    }

                    printf("���ѧ���ɼ�������1���ֶ�����ɼ�������2\n");
                    scanf("%d", &flag);
                    if (flag == 1) {
                        int* coursesNumberID;
                        float* score;

                        int perStudentCoursesCount = 10 + random(3);//һ��ѧ����10-12�ڿ�
                        coursesNumberID = (int*)malloc(perStudentCoursesCount * sizeof(int));;
                        score = (float*)malloc(perStudentCoursesCount * sizeof(float));

                        for (int j = 0; j < perStudentCoursesCount; j++) {
                            struct Course course = courses[random(coursesCount)];
                            coursesNumberID[j] = course.numberID;
                            score[j] = randomFloat(course.score);
                        }

                        if (addStudentScores(students, courses, studentScores, studentsCount, numberID, coursesNumberID, score, perStudentCoursesCount)) {
                            printf("����ѧ���ɼ��ɹ�\n");
                        }
                        else {
                            printf("����ѧ���ɼ�ʧ��\n");
                        }
                    }
                    else if (flag == 2) {
                        int* coursesNumberID;
                        float* score;
                        int perStudentCoursesCount = 0;
                        printf("����γ���Ŀ:\n");
                        scanf("%d", &perStudentCoursesCount);
                        coursesNumberID = (int*)malloc(perStudentCoursesCount * sizeof(int));;
                        score = (float*)malloc(perStudentCoursesCount * sizeof(float));
                        for (int i = 0; i < perStudentCoursesCount; i++) {
                            printf("�����%d���γ̵�ID:\n", i + 1);
                            scanf("%d", coursesNumberID[i]);
                            printf("�����%d���γ̵ĳɼ�:\n", i + 1);
                            scanf("%.2f", score[i]);
                        }
                        if (addStudentScores(students, courses, studentScores, studentsCount, numberID, coursesNumberID, score, perStudentCoursesCount)) {
                            printf("����ѧ���ɼ��ɹ�\n");
                        }
                        else {
                            printf("����ѧ���ɼ�ʧ��\n");
                        }
                    }
                }
                else if (flag == 2) {
                    int numberID;
                    char* name[10];
                    int preClass;
                    int score;
                    printf("����γ�ID(�������6λ��)��\n");
                    scanf("%d", &numberID);

                    printf("����γ����ƣ�\n");
                    scanf("%s", name);
                    printf("����γ�%s�����пε�ID��\n", name);
                    scanf("%d", &preClass);
                    printf("����γ�%s��ѧ�֣�\n", name);
                    scanf("%d", &score);

                    if (addCourse(courses, &coursesCount, numberID, name, preClass, score)) {
                        printf("���ӿγ̳ɹ�\n");
                    }
                    else {
                        printf("���ӿγ�ʧ��\n");
                    }
                } 
                break;
            case 2:
                printf("����Ҫɾ����ѧ��ID��\n");
                int deleteStudentNumberID = 0;
                scanf("%d", &deleteStudentNumberID);
                
                if (deleteStudent(students, &studentsCount, studentScores, deleteStudentNumberID)) {
                    printf("ѧ��ɾ���ɹ�\n");
                }
                else {
                    printf("�޸�ѧ�����ѧ���޳ɼ�\n");
                }
                break;
            case 3:
                printf("����Ҫ�޸ĵ�ѧ��ID��\n");
                int editStudentNumberID = 0;
                scanf("%d", &editStudentNumberID);

                int editFlag = 0;
                printf("����Ҫ�޸ĵ�����\n1��������\n2�����Ա�\n3��������\n4����Ժϵ\n");
                scanf("%d", &editFlag);

                switch (editFlag){
                    case 1:
                        printf("���������֣�\n");
                        char newName[16] = { 0 };
                        scanf("%s", newName);
                        if (editStudentName(students, studentsCount, editStudentNumberID, newName)) {
                            printf("�޸�ѧ�������ɹ�\n");
                        }
                        else {
                            printf("�޸�ѧ������ʧ�ܣ����޸�ѧ��\n");
                        }
                        break;
                    case 2:
                        printf("�������Ա�1Ϊ�У�0ΪŮ����\n");
                        int newGender = 0;
                        scanf("%d", &newGender);
                        if (editStudentGender(students, studentsCount, editStudentNumberID, newGender)) {
                            printf("�޸�ѧ���Ա�ɹ�\n");
                        }
                        else {
                            printf("�޸�ѧ���Ա�ʧ�ܣ����޸�ѧ��\n");
                        }
                        break;
                    case 3:
                        printf("���������䣺\n");
                        int newAge = 0;
                        scanf("%d", &newAge);
                        if (editStudentAge(students, studentsCount, editStudentNumberID, newAge)) {
                            printf("�޸�ѧ������ɹ�\n");
                        }
                        else {
                            printf("�޸�ѧ������ʧ�ܣ����޸�ѧ��\n");
                        }
                        break;
                    case 4:
                        printf("������Ժϵ��\n");
                        char newDepartment[16] = { 0 };
                        scanf("%s", newDepartment);
                        if (editStudentDepartment(students, studentsCount, editStudentNumberID, newDepartment)) {
                            printf("�޸�ѧ��Ժϵ�ɹ�\n");
                        }
                        else {
                            printf("�޸�ѧ��Ժϵʧ�ܣ����޸�ѧ��\n");
                        }
                        break;
                    default:
                        break;
                }

                break;
            case 4:
                printf("������ҷ�ʽ\n1����ʹ��ID����ѧ��\n2����ʹ����������ѧ��\n");
                int findFlag = 0;
                int findSuccess = 0;
                scanf("%d", &findFlag);

                int idxStudent = 0;
                switch (findFlag) {
                    case 1:
                        printf("����ID��\n");
                        int findNumberID = 0;
                        scanf("%d", &findNumberID);
                        findSuccess = findStudent(students, &idxStudent, findNumberID, studentsCount);
                        break;
                    case 2:
                        printf("�������֣�\n");
                        char findName[16];
                        scanf("%s", findName);
                        findSuccess = findStudentWithName(students, &idxStudent, findName, studentsCount);
                        break;
                    default:
                        break;
                }

                if (findSuccess) {
                    printf("���ҳɹ���%s����Ϣ����:\n", (students[idxStudent].gender) ? "��" : "��");
                    printf("ѧ��:%d\n", students[idxStudent].numberID);
                    printf("����:%s\n", students[idxStudent].name);
                    printf("�Ա�:%s\n", (students[idxStudent].gender) ? "��" : "Ů");
                    printf("����:%d\n", students[idxStudent].age);
                    printf("Ժϵ:%s\n", students[idxStudent].department);

                    int displayScoreFlag = 0;
                    printf("�Ƿ�Ҫ��ʾ%s�ĳɼ���Ϣ��\n0��������ʾ\n1������ʾ\n", (students[idxStudent].gender) ? "��" : "��");
                    scanf("%d", &displayScoreFlag);

                    if (displayScoreFlag) {
                        int idxStudentScore = 0;
                        if (findStudentScore(studentScores, &idxStudentScore, students[idxStudent].numberID, studentsCount)) {
                            printf("�ҵ��ɼ���Ϣ������:\n");
                            for (int i = 0; i < studentScores[idxStudentScore].coursesCount; i++) {
                                int idxCourse = 0;
                                findCourse(courses, &idxCourse, studentScores[idxStudentScore].courseNumberID[i], coursesCount);
                                printf("�γ�ID%d���γ�����%s���������÷�/�γ�ѧ�֣�Ϊ%.2f/%d\n", courses[idxCourse].numberID, courses[idxCourse].name, studentScores[idxStudentScore].score[i], courses[idxCourse].score);
                            }
                        }
                        else {
                            printf("δ�ҵ��ɼ���Ϣ\n");

                        }
                    }
                }
                else {
                    printf("���޴���\n");
                }
                break;
            default:
                break;
        }
    }

    saveStudentsData(jsonStudents, students, studentsCount, "students.json");
    saveCoursesData(jsonCourses, courses, coursesCount, "courses.json");
    saveStudentScoresData(jsonStudentScores, studentScores, studentsCount, "studentScores.json");

    return 0;
}

//�������ѧ����Ϣ
void generateStudentsData(int count, struct Student* students) {
    
    struct Student temp;

    int studentNumberID = 0;
    int nameLen = 0;
    char* name[20] = { 0 };
    int gender = 0;
    int age = 0;

    char* strNumber[6] = { 0 };
    char departments[6][20] = {
        "Science",
        "Technology",
        "Engineering",
        "Art",
        "Math",
        "Game"
    };
    for (int i = 0; i < count; i++) {
        printf("��%d��ѧ��\n", i+1);
        generateStr(strNumber, 1, 0, 6);//����6λ�����ַ���
        studentNumberID = atoi(strNumber);

        printf("ѧ��:%d\n", studentNumberID);

        //3��6λ������
        nameLen = 3 + random(4);
        generateStr(name, 0, 0, nameLen);//����6λ�ַ���
        printf("����:%s\n", name);

        //1�У�0Ů
        gender = random(2);
        printf("�Ա�:%d\n", gender);

        //����17-22��
        age = 17 + random(6);
        printf("����:%d\n", age);

        //6��Ժϵ����һ��
        char* department = "Science";
        department = departments[random(6)];
        printf("Ժϵ:%s\n\n", department);

        students[i].numberID = studentNumberID;
        strcpy(students[i].name, name);
        students[i].gender = gender;
        students[i].age = age;
        strcpy(students[i].department, department);

        for (int j = 1; j < i; j++) {//ѧ��ð�ݷ�����
            for (int k = 0; k < i - j + 1; k++) {
                if (students[k].numberID > students[k + 1].numberID) {
                    temp = students[k];
                    students[k] = students[k + 1];
                    students[k + 1] = temp;
                }
            }
        }
    }
}

//������ɿγ���Ϣ
void generateCoursesData(int count, struct Course* courses) {
    
    struct Course temp;

    int numberID = 0;
    char* numberStr[10] = { 0 };
    int nameLen = 0;
    char name[20] = { 0 };
    int preClass = 0;
    int score = 0;

    for (int i = 0; i < count; i++) {
        printf("��%d���γ�\n", i + 1);
        generateStr(numberStr, 1, 0, 4);//����4λ���γ�id
        numberID = atoi(numberStr);
        printf("ID:%d\n", numberID);

        nameLen = 3 + random(4);
        generateStr(name, 0, 0, nameLen);//����6λ�ַ���
        printf("����:%s\n", name);

        score = 1 + random(5);//1-5��
        printf("ѧ��:%d\n", score);


        courses[i].numberID = numberID;
        strcpy(courses[i].name, name);
        courses[i].score = score;

        for (int j = 1; j < i; j++) {//�γ�IDð�ݷ�����
            for (int k = 0; k < i - j + 1; k++) {
                if (courses[k].numberID > courses[k + 1].numberID) {
                    temp = courses[k];
                    courses[k] = courses[k + 1];
                    courses[k + 1] = temp;
                }
            }
        }
    }

    //��ֵÿ���γ̵� ���п�ID
    for (int i = 0; i < count; i++) {
        courses[i].preClass = courses[random(count)].numberID;
        printf("�γ�%d�����п���:%d\n", courses[i].numberID, courses[i].preClass);
    }
}

void generateStudentScoresData(int studentsCount, int coursesCount, struct StudentScore* studentScores, struct Student* students, struct Course* courses) {
    
    struct StudentScore temp;

    int studentNumberID = 0;
    int* courseNumberID;
    float* score;

    for (int i = 0; i < studentsCount; i++) {
        int perStudentCoursesCount = 10 + random(3);//һ��ѧ����10-12�ڿ�
        courseNumberID = (int*)malloc(perStudentCoursesCount * sizeof(int));;
        score = (float*)malloc(perStudentCoursesCount * sizeof(float));
        studentScores[i].coursesCount = perStudentCoursesCount;

        printf("��%d��ѧ��\n", i + 1);
        studentNumberID = students[i].numberID;
        studentScores[i].studentNumberID = studentNumberID;
        printf("ѧ��:%d\n", studentNumberID);
        studentScores[i].courseNumberID = (int*)malloc(perStudentCoursesCount * sizeof(int));
        studentScores[i].score = (int*)malloc(perStudentCoursesCount * sizeof(int));
        for (int j = 0; j < perStudentCoursesCount; j++) {
            struct Course course = courses[random(coursesCount)];
            courseNumberID[j] = course.numberID;
            score[j] = randomFloat(course.score);
        }
        memcpy(studentScores[i].courseNumberID, courseNumberID, sizeof(int) * perStudentCoursesCount);
        memcpy(studentScores[i].score, score, sizeof(float) * perStudentCoursesCount);
        for (int j = 0; j < perStudentCoursesCount; j++) {
            printf("�γ�ID:%d\n", studentScores[i].courseNumberID[j]);
            printf("�÷�:%.2f\n", studentScores[i].score[j]);
        }
        for (int j = 1; j < i; j++) {//ѧ��ð�ݷ�����
            for (int k = 0; k < i - j + 1; k++) {
                if (studentScores[k].studentNumberID > studentScores[k + 1].studentNumberID) {
                    temp = studentScores[k];
                    studentScores[k] = studentScores[k + 1];
                    studentScores[k + 1] = temp;
                }
            }
        }
    }
}

void saveStudentsData(cJSON* json, struct Student* students, int count, char fileName[]) {
    for (int i = 0; i < count; i++) {
        char string[16] = { 0 };
        _itoa(students[i].numberID, string, 10);
        //��������
        cJSON* array = NULL;
        cJSON_AddItemToObject(json, string, array = cJSON_CreateArray());
        cJSON* obj = NULL;
        cJSON_AddItemToArray(array, obj = cJSON_CreateObject());
        cJSON_AddItemToObject(obj, "name", cJSON_CreateString(students[i].name));
        cJSON_AddItemToObject(obj, "gender", cJSON_CreateBool(students[i].gender));
        cJSON_AddItemToObject(obj, "age", cJSON_CreateNumber(students[i].age));
        cJSON_AddItemToObject(obj, "department", cJSON_CreateString(students[i].department));
    }
    //��������
    FILE* fp = fopen(fileName, "w");
    char* buf = cJSON_Print(json);
    fwrite(buf, strlen(buf), 1, fp);
    fclose(fp);
    cJSON_Delete(json);
}

void saveCoursesData(cJSON* json, struct Course* courses, int count, char fileName[]) {
    for (int i = 0; i < count; i++) {
        char string[16] = { 0 };
        _itoa(courses[i].numberID, string, 10);
        //��������
        cJSON* array = NULL;
        cJSON_AddItemToObject(json, string, array = cJSON_CreateArray());
        cJSON* obj = NULL;
        cJSON_AddItemToArray(array, obj = cJSON_CreateObject());
        cJSON_AddItemToObject(obj, "name", cJSON_CreateString(courses[i].name));
        cJSON_AddItemToObject(obj, "score", cJSON_CreateNumber(courses[i].score));
        cJSON_AddItemToObject(obj, "preClass", cJSON_CreateNumber(courses[i].preClass));
    }
    //��������
    FILE* fp = fopen(fileName, "w");
    char* buf = cJSON_Print(json);
    fwrite(buf, strlen(buf), 1, fp);
    fclose(fp);
    cJSON_Delete(json);
}

void saveStudentScoresData(cJSON* json, struct StudentScore* studentScores, int count, char fileName[]) {
    for (int i = 0; i < count; i++) {
        char string[16] = { 0 };
        _itoa(studentScores[i].studentNumberID, string, 10);
        //��������
        cJSON* array = NULL;
        cJSON_AddItemToObject(json, string, array = cJSON_CreateArray());
        cJSON* obj = NULL;
        cJSON_AddItemToArray(array, obj = cJSON_CreateObject());
        cJSON_AddItemToObject(obj, "coursesCount", cJSON_CreateNumber(studentScores[i].coursesCount));
        cJSON_AddItemToObject(obj, "courseNumberID", cJSON_CreateIntArray(studentScores[i].courseNumberID, studentScores[i].coursesCount));
        cJSON_AddItemToObject(obj, "score", cJSON_CreateFloatArray(studentScores[i].score, studentScores[i].coursesCount));
    }
    //��������
    FILE* fp = fopen(fileName, "w");
    char* buf = cJSON_Print(json);
    fwrite(buf, strlen(buf), 1, fp);
    fclose(fp);
    cJSON_Delete(json);
}

int addStudent(struct Student* students, int* studentsCount, int addNumberID, char addName[], int addGender, int addAge, char addDepartment[]) {
    clock_t start,end;
    start = clock();

    *studentsCount += 1;

    struct Student insertTarget = { addNumberID, "", addGender, addAge, "" };

    strcpy(insertTarget.name, addName);
    strcpy(insertTarget.department, addDepartment);

    insertTarget.gender = addGender;

    students[*studentsCount - 1] = insertTarget;
    sortStudents(students, *studentsCount);

    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int addCourse(struct Course* courses, int* coursesCount, int addNumberID, char addName[], int addPreClass, int addScore) {
    clock_t start,end;
    start = clock();

    *coursesCount += 1;

    struct Course insertTarget = { 0 };

    char string[16] = { 0 };
    _itoa(addNumberID, string, 10);

    strcpy(insertTarget.name, addName);
    insertTarget.preClass = addPreClass;
    insertTarget.numberID = addNumberID;
    insertTarget.score = addScore;

    courses[*coursesCount - 1] = insertTarget;

    sortCourses(courses, *coursesCount);

    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int addStudentScores(struct Student* students, struct Course* courses, struct StudentScore* studentScores, int studentsCount , int addStudentNumberID, int addCoursesNumberID[], float addScore[], int addCoursesCount) {
    clock_t start,end;
    start = clock();
    
    int idx = 0;
    if (findStudentScore(studentScores, &idx, addStudentNumberID, studentsCount)) {
        return 0;
    }
    studentScores[idx].studentNumberID = addStudentNumberID;
    studentScores[idx].coursesCount = addCoursesCount;
    studentScores[idx].courseNumberID = (int*)malloc(addCoursesCount * sizeof(int));;
    studentScores[idx].score = (float*)malloc(addCoursesCount * sizeof(float));
    memcpy(studentScores[idx].courseNumberID, addCoursesNumberID, sizeof(int) * addCoursesCount);
    memcpy(studentScores[idx].score, addScore, sizeof(float) * addCoursesCount);

    studentScores[studentsCount - 1] = studentScores[idx];
    sortStudentScores(studentScores, studentsCount);

    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int findStudent(struct Student* students, int* studentResultIdx, int studentNumberID, int studentsCount) {
    clock_t start,end;
    start = clock();
    for (int i = 0; i < studentsCount; i++) {
        if (students[i].numberID == studentNumberID) {
            *studentResultIdx = i;
            end = clock();
            double dur = (double)(end - start);
            printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
            return 1;
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 0;
}

int findStudentWithName(struct Student* students, int* studentResultIdx, char studentName[], int studentsCount) {
    clock_t start,end;
    start = clock();
    for (int i = 0; i < studentsCount; i++) {
        if (strcmp(students[i].name, studentName) == 0) {
            *studentResultIdx = i;
            end = clock();
            double dur = (double)(end - start);
            printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
            return 1;
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 0;
}

int findCourse(struct Course* courses, int* courseResultIdx, int courseNumberID, int coursesCount) {
    clock_t start,end;
    start = clock();
    for (int i = 0; i < coursesCount; i++) {
        if (courses[i].numberID == courseNumberID) {
            *courseResultIdx = i;
            end = clock();
            double dur = (double)(end - start);
            printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
            return 1;
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 0;
}

int findStudentScore(struct StudentScore* studentScores, int* studentScoreResultIdx, int studentNumberID, int studentsCount) {
    clock_t start,end;
    start = clock();
    for (int i = 0; i < studentsCount; i++) {
        if (studentScores[i].studentNumberID == studentNumberID) {
            *studentScoreResultIdx = i;
            end = clock();
            double dur = (double)(end - start);
            printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
            return 1;
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 0;
}

void sortStudents(struct Student* students, int studentsCount) {
    clock_t start,end;
    start = clock();
    struct Student temp;
    for (int j = 1; j < studentsCount; j++) {//ð�ݷ�����
        for (int k = 0; k < studentsCount - j + 1; k++) {
            if (students[k].numberID > students[k + 1].numberID) {
                temp = students[k];
                students[k] = students[k + 1];
                students[k + 1] = temp;
            }
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
}

void sortCourses(struct Course* courses, int coursesCount) {
    clock_t start,end;
    start = clock();
    struct Course temp;
    for (int j = 1; j < coursesCount - 1; j++) {//ð�ݷ�����
        for (int k = 0; k < coursesCount - j; k++) {
            if (courses[k].numberID > courses[k + 1].numberID) {
                temp = courses[k];
                courses[k] = courses[k + 1];
                courses[k + 1] = temp;
            }
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
}

void sortStudentScores(struct StudentScore* studentScores, int studentsCount) {
    clock_t start,end;
    start = clock();
    struct StudentScore temp;
    for (int j = 1; j < studentsCount - 1; j++) {//ð�ݷ�����
        for (int k = 0; k < studentsCount - j; k++) {
            if (studentScores[k].studentNumberID > studentScores[k + 1].studentNumberID) {
                temp = studentScores[k];
                studentScores[k] = studentScores[k + 1];
                studentScores[k + 1] = temp;
            }
        }
    }
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
}

int deleteStudent(struct Student* students, int* studentsCount, struct StudentScore* studentScores, int deleteStudentNumberID) {
    clock_t start,end;
    start = clock();
    int idx = 0;
    if (!findStudent(students, &idx, deleteStudentNumberID, *studentsCount)) {
        return 0;
    }
    *studentsCount -= 1;
    struct Student* newStudents;
    newStudents = (struct Student*)malloc((*studentsCount) * sizeof(struct Student));
    int flag = 0;
    for (int i = 0; i < *studentsCount; i++) {
        if (students[i].numberID != deleteStudentNumberID) {
            if (flag) {
                //newStudents[i - 1] = students[i];
                students[i] = students[i + 1];
            }
        }
        else {
            students[i] = students[i + 1];
            flag = 1;
        }
    }
    memcpy(students, newStudents, sizeof(int) * (*studentsCount));
    
    int idx2 = 0;
    if (!findStudentScore(studentScores, &idx2, deleteStudentNumberID, *studentsCount)) {
        return 0;
    }
    struct StudentScore* newStudentScores;
    newStudentScores = (struct StudentScore*)malloc(*studentsCount * sizeof(struct StudentScore));
    
    for (int i = 0; i < *studentsCount; i++) {
        if (studentScores[i].studentNumberID != studentScores[idx2].studentNumberID) {
            newStudentScores[i] = studentScores[i];
        }
    }
    memcpy(studentScores, newStudentScores, sizeof(int) * (*studentsCount));
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int editStudentName(struct Student* students, int studentsCount, int editStudentNumberID, char newName[]) {
    clock_t start,end;
    start = clock();
    int idx = 0;
    if (!findStudent(students, &idx, editStudentNumberID, studentsCount)) {
        return 0;
    }
    strcpy(students[idx].name, newName);
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int editStudentGender(struct Student* students, int studentsCount, int editStudentNumberID, int newGender) {
    clock_t start,end;
    start = clock();
    int idx = 0;
    if (!findStudent(students, &idx, editStudentNumberID, studentsCount)) {
        return 0;
    }
    students[idx].gender = newGender;
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int editStudentAge(struct Student* students, int studentsCount, int editStudentNumberID, int newAge) {
    clock_t start,end;
    start = clock();
    int idx = 0;
    if (!findStudent(students, &idx, editStudentNumberID, studentsCount)) {
        return 0;
    }
    students[idx].age = newAge;
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int editStudentDepartment(struct Student* students, int studentsCount, int editStudentNumberID, char newDepartment[]) {
    clock_t start,end;
    start = clock();
    int idx = 0;
    if (!findStudent(students, &idx, editStudentNumberID, studentsCount)) {
        return 0;
    }
    strcpy(students[idx].department, newDepartment);
    end = clock();
    double dur = (double)(end - start);
    printf("���к�ʱ:%f\n", (dur / CLOCKS_PER_SEC));
    return 1;
}

int random(int m) {
    int result = rand() % m;
    return result;//�������������0~m-1֮��
}

float randomFloat(int m) {
    int result = rand() % (m * 100);
    return (float)result / 100;
}

//�������ָ�����ȵ��ַ��������Ե��ڲ�����������Сд/��д/����
void generateStr(char* str, int isGenerateInt, int isGenerateBigCase, int strLen) {
    int i;

    if (isGenerateInt) {
        for (i = 0; i < strLen; i++) {
            str[i] = random(10) + '0';
        }
    }
    else {
        if (isGenerateBigCase) {
            for (i = 0; i < strLen; i++) {
                str[i] = random(26) + 'A';
            }
        }
        else {
            for (i = 0; i < strLen; i++) {
                str[i] = random(26) + 'a';
            }
        }
    }
}