#include<bits/stdc++.h>
#include"core_function.h"
#include"add_function.h" 
#include"delete_function.h"
#include"modify_function.h"
#include"check_function.h"
#include"clear_function.h"
using namespace std;
int main(void)
{
	read_in_file();
	menu();
	return 0;
}
//	for(Student* i=table_1_head;i!=NULL;i=i->next)
//	{cout<<i->stu_id<<i->stu_name<<i->sex<<i->age<<i->department<<endl;
//		for(int j=0;j<i->course_score.size();j++)
//		cout<<i->course_score[j].first<<" "<<i->course_score[j].second<<endl;
//	}
//		for(Course* i=table_2_head;i!=NULL;i=i->next)
//	cout<<i->cour_id<<i->cour_name<<i->base_cour_name<<i->score<<endl;
