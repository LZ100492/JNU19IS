#ifndef _DECLARATION_H
#define _DECLARATION_H
#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> P;
struct Student{
	long stu_id;
	string stu_name;
	string sex;
	int age;
	string department;
	vector<P> course_score;
	map<int,int> course;
	Student* next;
	Student():next(NULL){};
};
struct Course{
	int cour_id;
	string cour_name;
	string base_cour_name;
	int score;
	Course* next;
	Course():next(NULL){};
};
extern void menu(void);
extern void help(void);
extern void select_function(void);
extern void read_in_file(void);
extern void save_file(void);
extern void add_(void);
extern void delete_(void);
extern void modify_(void);
extern void check_(void);
extern void clear_(void);
extern void add_stu_info_table(void);
extern void add_course_info_table(void);
extern void add_stu_score_info_table(void);
extern void	delete_stu_info_table(void);
extern void	delete_course_info_table(void);
extern void	delete_stu_score_info_table(void);
extern void	modify_stu_info_table(void);
extern void	modify_course_info_table(void);
extern void	modify_stu_score_info_table(void);
extern void	check_stu_info_table(void);
extern void	check_course_info_table(void);
extern void	check_stu_score_info_table(void);
extern bool stu_id_not_valid(long);
extern Student* find_exist_stu(long);
extern Student* find_former_stu(long);
extern Course* find_former_course(int);
extern Course* find_exist_course(int);
Student* table_1_head=NULL;
Course* table_2_head=NULL;
bool file_1_clear=false;
bool file_2_clear=false;
bool file_3_clear=false;
#endif 
