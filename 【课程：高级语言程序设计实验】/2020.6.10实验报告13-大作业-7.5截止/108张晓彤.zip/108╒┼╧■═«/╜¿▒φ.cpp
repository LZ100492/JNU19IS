#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void creat() 
{
	FILE* fp1 = fopen("Students.txt", "w"); 
	if (fp1 == NULL) {
		printf("Failed to open file");
		exit(0);
	}
	char col[6][9] = {"math","chinese","music","physics","English","art"};
	char gen[2] = { 'F','M' };
	int num;
	char name[4];
	name[3] = '\0';
	char gender;
	int age;
	char college;
	
	for (int i = 0; i < 1500; i++)
	{
		num=i+1;
		name[0]= rand() % 26 + 65;
		name[1]= rand() % 26 + 65;
		name[2]= rand() % 26 + 65;
		gender=gen[rand()%2];
		age = rand()%6 + 17;
		fprintf(fp1,"%d %s %c %d %s\n", num,name, gender, age, col[rand() % 6]);
		
	}
	fclose(fp1);


	FILE* fp2 = fopen("Courses.txt", "w");
	if (fp2 == NULL) {
		printf("Failed to open file");
		exit(0);
	}
	int conum;
	char coname[4];
	coname[3] = '\0';
	char copre;
	int credit;
	srand(time(0));
	for (int i = 0; i < 50; i++)
	{
		conum = i + 1;
		coname[0] = rand() % 26 + 97;
		coname[1] = rand() % 26 + 97;
		coname[2] = rand() % 26 + 97;
		copre = rand() % 26 + 65;
		credit = rand()%5+1;
		fprintf( fp2,"%d %s %c %d\n", conum, coname, copre,credit);

	}
	fclose(fp2);

	FILE* fp3 = fopen("marks.txt", "w");
	if (fp3 == NULL) {
		printf("Failed to open file");
		exit(0);
	}
	int mark;
	int cou_num;
	int stu_num;
	int list[10];
	for (int i = 0; i < 1500; i++)
	{
		stu_num = i + 1;
		
		for (int j = 0; j < 10; j++)
		{
			ran:cou_num = rand() % 50+1;
			list[j] = cou_num;
			for (int k = 0; k < j; k++)
			{
				if (list[j] == list[k])
				{
					goto ran;
				}
			}
			mark = rand() % 50 + 50;
			fprintf(fp3,"%d %d %d\n", stu_num, cou_num, mark);
		}
	}
	fclose(fp3);
}