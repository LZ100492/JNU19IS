#include <stdio.h>
#include  <stdlib.h> 
#define N 1000
#define M 50
typedef struct student    
{int stuid;
 char name[10];
 char sex;
 int sui;
 char yuan;
 int score[M];   
 }STUDENT;
void add(STUDENT stu[],n,m ) {
 	fprintf(a,"%d%d%s",stu.stuid,stu.sui,stu.name); 	
}
void find(){
	scanf("%d",&k);
	for(i=1,i<N,i++){
		if(stu.stuid==k)
		printf("%s%d",stu.name,stu.sui)	}
		}
void correct(int f,int k,int l){
	scanf("%d",&k);
	for(i=1,i<N,i++){
		if(stu.stuid==k){
			f=stu.sui;
		}	
}
int main()
 {STUDENT stu[N]; char fname[32]; 
 int n=0,m=M,k=0; system("cls");
 FILE *a = fopen("C:\\1.txt","r+");
 FILE *b = fopen("C:\\2.txt","r+");
 FILE *c = fopen("C:\\3.txt","r+");
 do{  k=menu(); switch(k)
  { case 0: break; 
  case 1: printf("��¼������ѧ����Ϣ��");
  scanf("%d%d%s%d",stu.stuid,stu.sui,stu.yuan,stu.score) 
  add(stu,n,m); break;
  case 2: printf("�������ѧ��"); 
  find(int f,int k,int l);   break;
  case 3:  printf("�������޸ĵ�ѧ��ѧ�� ");
  correct(); break; 
  } }while(k); return 0; }
int menu() {int n=0; printf("********************\n"); 
 printf("1: ����ѧ��\n");
 printf("2: ����ѧ��\n"); 
 printf("3: �޸�����\n");
 printf("0: �˳���\n"); 
 printf("********************\n"); 
 printf("��ѡ��");
 scanf("%d",&n); 
   return n; 
   }           
	
	
	
	
	
