#include<stdio.h>
#include<iostream>
#include<string.h>
#include<stdlib.h>
using namespace std;

struct name_node {
    char name[20];
    int number;
    int gender;
    char major[20];
    int age;
    struct name_node *lch, *rch, *fth;
    name_node () {
        number=-1; gender=-1; age=-1;
        lch=NULL; rch=NULL; fth=NULL;
    }
    void build () {
        printf("Student's name : ");
        scanf("%s", name);
        printf("Student's number : ");
        scanf("%d", &number);
        printf("Student's gender : ");
        scanf("%d", &gender);
        printf("Student's major : ");
        scanf("%s", major);
        printf("Student's age : ");
        scanf("%d", &age);
        lch=NULL; rch=NULL; fth=NULL;
    }
    void print () {
        cout<<"name:"<<name<<" ";
        cout<<"number:"<<number<<" ";
        cout<<"gender:"<<(gender==1?"male":"female")<<" ";
        cout<<"major:"<<major<<" ";
        cout<<"age:"<<age<<"\n";
    }
};
bool name_cmp (name_node a,name_node b) {
    return a.number<=b.number;
}
void add_name (name_node *x,name_node *y) {
    if (name_cmp(*x,*y)) {
        if (x->rch==NULL)
            x->rch=y, y->fth=x;
        else add_name (x->rch, y);
    }
    else {
        if (x->lch==NULL)
            x->lch=y, y->fth=x;
        else add_name (x->lch, y);
    }
}
name_node *name_search (name_node *now, int num) {
    if (now->number==num)
        return now;
    if (now->number<num)
        if (now->rch!=NULL)
            return name_search(now->rch, num);
        else return NULL;
    if (now->number>num)
        if (now->lch!=NULL)
            return name_search(now->lch, num);
        else return NULL;
    return NULL;
}
name_node *name_search_nm (name_node *now, char nm[]) {
    if (strcmp(now->name,nm)==0)
        return now;
    name_node *res;
    if (now->rch!=NULL)
        if ((res=name_search_nm(now->rch, nm))!=NULL)
            return res;
    if (now->lch!=NULL)
        return name_search_nm(now->lch, nm);
    return NULL;
}
void name_output (name_node *now) {
    if (now->lch!=NULL)
        name_output (now->lch);
    if (now->number!=-1)
        now->print();
    if (now->rch!=NULL)
        name_output (now->rch);
}

struct lesson_node {
    char name[20];
    int number;
    int former;
    int score;
    struct lesson_node *lch, *rch, *fth;
    lesson_node () {
        number=-1; former=-1; score=-1;
        lch=NULL; rch=NULL; fth=NULL;
    }
    void build () {
        printf("Lesson name : ");
        scanf("%s", name);
        printf("Lesson number : ");
        scanf("%d", &number);
        printf("Number of former lesson : ");
        scanf("%d", &former);
        printf("Score : ");
        scanf("%d", &score);
        lch=NULL; rch=NULL; fth=NULL;
    }
    void print () {
        cout<<"lesson:"<<name<<" ";
        cout<<"number:"<<number<<" ";
        cout<<"former:"<<former<<" ";
        cout<<"score:"<<score<<"\n";
    }
};
bool lesson_cmp (lesson_node a,lesson_node b) {
    return a.number<=b.number;
}
void add_lesson (lesson_node *x,lesson_node *y) {
    if (lesson_cmp(*x,*y)) {
        if (x->rch==NULL)
            x->rch=y, y->fth=x;
        else add_lesson (x->rch, y);
    }
    else {
        if (x->lch==NULL)
            x->lch=y, y->fth=x;
        else add_lesson (x->lch, y);
    }
}
lesson_node *lesson_search (lesson_node *now, int num) {
    if (now->number==num)
        return now;
    if (now->number<num)
        if (now->rch!=NULL)
            return lesson_search(now->rch, num);
        else return NULL;
    if (now->number>num)
        if (now->lch!=NULL)
            return lesson_search(now->lch, num);
        else return NULL;
    return NULL;
}
lesson_node *lesson_search_nm (lesson_node *now, char nm[]) {
    if (strcmp(now->name,nm)==0)
        return now;
    lesson_node *res;
    if (now->rch!=NULL)
        if ((res=lesson_search_nm(now->rch, nm))!=NULL)
            return res;
    if (now->lch!=NULL)
        return lesson_search_nm(now->lch, nm);
    return NULL;
}
void lesson_output (lesson_node *now) {
    if (now->lch!=NULL)
        lesson_output (now->lch);
    if (now->number!=-1)
        now->print();
    if (now->rch!=NULL)
        lesson_output (now->rch);
}

struct grade_node {
    int stu_num;
    int les_num;
    int grade;
    struct grade_node *lch, *rch, *fth;
    grade_node () {
        stu_num=-1; les_num=-1; grade=-1;
        lch=NULL; rch=NULL; fth=NULL;
    }
    void build () {
        printf("Student number : ");
        scanf("%d", &stu_num);
        printf("Lesson number : ");
        scanf("%d", &les_num);
        printf("Grade : ");
        scanf("%d", &grade);
        lch=NULL; rch=NULL; fth=NULL;
    }
    void print () {
        cout<<"Student number:"<<stu_num<<" ";
        cout<<"Lesson number:"<<les_num<<" ";
        cout<<"Grade:"<<grade<<"\n";
    }
};
bool grade_cmp (grade_node a,grade_node b) {
    if (a.stu_num<b.stu_num)
        return true;
    else if (a.stu_num==b.stu_num && a.les_num<=b.les_num)
        return true;
    return false;
}
void add_grade (grade_node *x,grade_node *y) {
    if (grade_cmp(*x,*y)) {
        if (x->rch==NULL)
            x->rch=y, y->fth=x;
        else add_grade (x->rch, y);
    }
    else {
        if (x->lch==NULL)
            x->lch=y, y->fth=x;
        else add_grade (x->lch, y);
    }
}
grade_node *grade_search_stu (grade_node *now, int num) {
    if (now->stu_num==num)
        return now;
    if (now->stu_num<num)
        if (now->rch!=NULL)
            return grade_search_stu(now->rch, num);
        else return NULL;
    if (now->stu_num>num)
        if (now->lch!=NULL)
            return grade_search_stu(now->lch, num);
        else return NULL;
    return NULL;
}
grade_node *grade_search_les (grade_node *now, int num) {

    if (now->les_num==num)
        return now;
    grade_node *res;
    if (now->rch!=NULL)
        if ((res=grade_search_les(now->rch, num))!=NULL)
            return res;
    if (now->lch!=NULL)
        return grade_search_les(now->lch, num);
    return NULL;
}
grade_node *grade_search_sl (grade_node *now, int stu, int les) {
    if (now->stu_num==stu && now->les_num==les)
        return now;
    if (now->stu_num<stu || (now->stu_num==stu && now->les_num<les))
        if (now->rch!=NULL)
            return grade_search_sl(now->rch, stu, les);
        else return NULL;
    if (now->stu_num>stu || (now->stu_num==stu && now->les_num>les))
        if (now->lch!=NULL)
            return grade_search_sl(now->lch, stu, les);
        else return NULL;
    return NULL;
}
void grade_delete (grade_node *root,grade_node *now) {
    if (now->fth->lch==now)
        now->fth->lch=NULL;
    else now->fth->rch=NULL;
    if (now->lch)
        now->lch->fth=NULL, add_grade(root, now->lch);
    if (now->rch)
        now->rch->fth=NULL, add_grade(root, now->rch);
    printf("delete : ");
    now->print();
}
void grade_output (grade_node *now) {
    if (now->lch!=NULL)
        grade_output (now->lch);
    if (now->stu_num!=-1)
        now->print();
    if (now->rch!=NULL)
        grade_output (now->rch);
}

name_node name_root;
lesson_node lesson_root;
grade_node grade_root;

void add () {
    int listnum;
    printf("List to be modified : 1.students 2.lessons 3.grades\n");
    scanf("%d", &listnum);
    name_node *now1;
    lesson_node *now2;
    grade_node *now3;
    switch (listnum) {
        case 1 :
            now1=(name_node*)malloc(sizeof(name_node));
            now1->build();
            add_name (&name_root, now1);
            printf("add : ");
            now1->print();
            break;
        case 2 :
            now2=(lesson_node*)malloc(sizeof(lesson_node));
            now2->build();
            add_lesson (&lesson_root, now2);
            printf("add : ");
            now2->print();
            break;
        case 3 :
            now3=(grade_node*)malloc(sizeof(grade_node));
            now3->build();
            add_grade (&grade_root, now3);
            printf("add : ");
            now3->print();
            break;
        default : printf("?\n");
    }
    cout<<"\n";
}

void del () {
    int listnum;
    printf("List to be modified : 1.students 2.lessons 3.grades\n");
    scanf("%d", &listnum);
    name_node *res1;
    lesson_node *res2;
    grade_node *res3;
    switch (listnum) {
        case 1 :
            int stunum;
            printf("Number of the student to be deleted : ");
            scanf("%d", &stunum);
            if((res1=name_search (&name_root, stunum))!=NULL) {
                printf("delete : "); res1->print();
                if (res1->fth->lch==res1)
                    res1->fth->lch=NULL;
                else res1->fth->rch=NULL;
                if (res1->lch)
                    res1->lch->fth=NULL, add_name(&name_root, res1->lch);
                if (res1->rch)
                    res1->rch->fth=NULL, add_name(&name_root, res1->rch);
            }
            else printf("Error : No matched record.\n");
            while((res3=grade_search_stu (&grade_root, stunum))!=NULL)
                grade_delete(&grade_root,res3);
            break;
        case 2 :
            int lesnum;
            printf("Number of lesson to be deleted : ");
            scanf("%d", &lesnum);
            if((res2=lesson_search (&lesson_root, lesnum))!=NULL) {
                if (res2->fth->lch==res2)
                    res2->fth->lch=NULL;
                else res2->fth->rch=NULL;
                if (res2->lch)
                    res2->lch->fth=NULL, add_lesson(&lesson_root, res2->lch);
                if (res2->rch)
                    res2->rch->fth=NULL, add_lesson(&lesson_root, res2->rch);
                printf("delete : "); res2->print();
            }
            else printf("Error : No matched record.\n");
            while((res3=grade_search_les (&grade_root, lesnum))!=NULL)
                grade_delete(&grade_root,res3);
            break;
        case 3 :
            int stu,les;
            printf("Student number : ");
            scanf("%d", &stu);
            printf("Lesson number : ");
            scanf("%d", &les);
            if((res3=grade_search_sl (&grade_root, stu, les))!=NULL)
                grade_delete(&grade_root,res3);
            else printf("Error : No matched record.\n");
            break;
        default : printf("?\n");
    }
    cout<<"\n";
}

void mod () {
    int listnum;
    printf("List to be modified : 1.students 2.lessons 3.grades\n");
    scanf("%d", &listnum);
    name_node *res1;
    lesson_node *res2;
    grade_node *res3;
    switch (listnum) {
        case 1 :
            int stunum;
            printf("Number of the student to be modified : ");
            scanf("%d", &stunum);
            if((res1=name_search (&name_root, stunum))!=NULL) {
                printf("origin : "); res1->print();
                printf("Student's name : "); scanf("%s", res1->name);
                printf("Student's number : "); printf("%d\n", res1->number);
                printf("Student's gender : "); scanf("%d", &(res1->gender));
                printf("Student's major : "); scanf("%s", res1->major);
                printf("Student's age : "); scanf("%d", &(res1->age));
                printf("modify : "); res1->print();
            }
            else printf("Error : No matched record.\n");
            break;
        case 2 :
            int lesnum;
            printf("Number of lesson to be modified : ");
            scanf("%d", &lesnum);
            if((res2=lesson_search (&lesson_root, lesnum))!=NULL) {
                printf("origin : "); res2->print();
                printf("Lesson name : "); scanf("%s", res2->name);
                printf("Lesson number : "); printf("%d\n", res2->number);
                printf("Number of former lesson : "); scanf("%d", &(res2->former));
                printf("Score : "); scanf("%d", &(res2->score));
                printf("modify : "); res2->print();
            }
            else printf("Error : No matched record.\n");
            break;
        case 3 :
            int stu,les;
            printf("Student number : ");
            scanf("%d", &stu);
            printf("Lesson number : ");
            scanf("%d", &les);
            if((res3=grade_search_sl (&grade_root, stu, les))!=NULL) {
                printf("origin : "); res3->print();
                printf("Student number : "); printf("%d\n", res3->stu_num);
                printf("Lesson number : "); printf("%d\n", res3->les_num);
                printf("Grade : "); scanf("%d", &(res3->grade));
                printf("modify : "); res3->print();
            }
            else printf("Error : No matched record.\n");
            break;
        default : printf("?\n");
    }
    cout<<"\n";
}

void srh () {
    int listnum,ins;
    char nm[20];
    name_node *res1;
    lesson_node *res2;
    grade_node *res3;
    printf("List to search in : 1.students 2.lessons 3.grades\n");
    scanf("%d", &listnum);
    switch(listnum) {
        case 1 :
            printf("Search by : 1.name 2.number\n");
            scanf("%d", &ins);
            switch(ins) {
                case 1 :
                    printf("Student's name : ");
                    scanf("%s", nm);
                    if ((res1=name_search_nm(&name_root,nm))!=NULL) {
                        printf("search : "); res1->print();
                    }
                    else printf("No matched record.\n");
                    break;
                case 2 :
                    int stu_num;
                    printf("Student's number : ");
                    scanf("%d", &stu_num);
                    if ((res1=name_search(&name_root,stu_num))!=NULL) {
                        printf("search : "); res1->print();
                    }
                    else printf("No matched record.\n");
                    break;
                default : printf("?\n");
            }
            break;
        case 2 :
            printf("Search by : 1.lesson name 2.lesson number\n");
            scanf("%d", &ins);
            switch(ins) {
                case 1 :
                    printf("Lesson name : ");
                    scanf("%s", nm);
                    if ((res2=lesson_search_nm(&lesson_root,nm))!=NULL) {
                        printf("search : "); res2->print();
                    }
                    else printf("No matched record.\n");
                    break;
                case 2 :
                    int les_num;
                    printf("Lesson number : ");
                    scanf("%d", &les_num);
                    if ((res2=lesson_search(&lesson_root,les_num))!=NULL) {
                        printf("search : "); res2->print();
                    }
                    else printf("No matched record.\n");
                    break;
                default : printf("?\n");
            }
            break;
        case 3 :
            int stu,les;
            printf("Student number : ");
            scanf("%d", &stu);
            printf("Lesson number : ");
            scanf("%d", &les);
            if((res3=grade_search_sl (&grade_root, stu, les))!=NULL)
                printf("search : "), res3->print();
            else printf("Error : No matched record.\n");
            break;
        default :printf("?\n");
    }
    cout<<"\n";
}

void prt () {
    name_output (&name_root);
    lesson_output (&lesson_root);
    grade_output (&grade_root);
    cout<<endl;
}

void sav () {
    freopen("xms.dat", "w", stdout);
    name_output (&name_root);
    cout<<endl;
    lesson_output (&lesson_root);
    cout<<endl;
    grade_output (&grade_root);
    cout<<endl;
    fclose(stdout);
}

int main()
{
    int ins=1, listnum;
    do {
        printf("option : 1.add 2.delete 3.modify 4.search 5.print 6.save 0.exit\n");
        scanf("%d", &ins);
        switch(ins) {
            case 1 : add (); break;
            case 2 : del (); break;
            case 3 : mod (); break;
            case 4 : srh (); break;
            case 5 : prt (); break;
            case 6 : sav (); break;
            case 0 : sav (); break;
            default : printf("?\n");
        }
    }while(ins);
    return 0;
}
/*
1
1
xms
3
1
Assassin's_Creed
19
1
1
hxy
1
2
Unknown
17
1
1
xms2
2
2
Clash_of_Clans
3
1
1
xms3
6
1
Honor_of_King
81
2
1
1
1
2
Assassin's_Creed
3
-1
23
1
2
C++
0
-1
0
1
2
Clash_of_Clans
1
-1
1
1
2
Honor_of_King
2
3
5
2
2
0
1
3
6
1
59
1
3
2
1
68
1
3
6
2
100
1
3
3
3
56
*/
