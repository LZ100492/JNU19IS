#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct student
{
	char num[10];
	char name[5];
	char sex;
	int age;
	char acad[5];
	struct student *next;
}stu[1000];
void writetxt(struct student* head)
{
	struct student* p;
	p = head;
	FILE* fp;
	fopen_s(&fp, "excel 1", "w");
	if (fp == NULL)
	{
		printf("cannot open");
		return;
	}
	while (p != NULL)
	{
		fwrite(p, sizeof(struct student), 1, fp);
		p = p->next;
	}
	fclose(fp);
}
struct student* insert(struct student* head)
{
	char ch;
	struct student* p, * p0, * p1;
	p = p1 = head;
}
struct student* del(struct student* head)
{
	FILE* fp;
	struct student* p1, * p2, * p0;
	p1 = p2 = head;
	char num[10];
	printf("input the delete number:");
	scanf_s("%s", num);
	while (p1 != NULL)
	{
		if (strcmp(p1->num, num) == 0)
		{
			p0 = p1;
			if (p1 = head)
			{
				head = p1->next;
				p1 = p2 = head;
				p1 = p2->next;
             }
			else
			{
				p0 = p1;
				p2->next = p1->next;
				p1 = p2->next;
			}
			break;
		}
	}
}
struct student* change(struct student* head)
{
	struct student* p = head;
	int age, m ;
	char name[5], sex,num[10];
	char* p1;
	while (1)
	{
		printf("������ѧ�ţ�");
		scanf_s("%s", num);
		p = head;
		while (p != NULL && strcmp(p->num, num) != 0)
		{
			p = p->next;
			if (p == NULL)
			{
				printf("��ѧ��������\n");
				break;
			}
		}
		m = 0;
		while (1)
		{
			printf("�������µ��������Ա����䣺");
			scanf_s("%s%c%d", name, &sex, &age);
			p1 = name;
			strcpy(p->name, p1);
			p->sex = sex;
			p->age = age;
		}
		writetxt(head);
		p = head;
		return head;
	}
}
void research(struct student* head)
{
	struct student* p1, * p2;
	p1 = p2 = head;
	int i, j, k = 0;
	char num[10],name[5], sex;
	int age;
	while (1)
	{
		p1 = head;
		printf("������ѧ��ѧ�ţ�");
		scanf("%s", num);
		while (p1 != NULL)
		{
			if (strcmp(p1->num, num) == 0)
			{
				printf("%s%5s%2s%4d", p1->num, p1->name, p1->sex, p1->age);
			}
		}
	}
}
void main()
{
	struct student* p;
	struct student* head;
	p = head;
	FILE* fp;
	fopen_s(&fp, "excel 1", "r");
	if (fp == NULL)
	{
		printf("cannot open");
		return;
	}
	while (p != NULL)
	{
		fread(p, sizeof(struct student), 1, fp);
		p = p->next;
	}
	while(1)
		switch ()
		{
		case 1:
			printf("ѧ����Ϣ����/n");
			head=insert(head);
			break;
		case 2:
			printf("ѧ����Ϣɾ��/n");
			head = del(head);
			break;
		case 3:
			printf("ѧ����Ϣ�޸�/n");
			change(head);
			break;
		case 4:
			printf("ѧ����Ϣ��ѯ");
			research(head);
			break;
			return;
		}
}
