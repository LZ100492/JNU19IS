#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include <malloc.h>
struct Student
{
	int num;
	char name[20];
	char sex[2];
	int age;
	char depart[30];
	struct Student *next;
};
void insert(struct Student **head); 
void print(struct Student *head);   
void dele(struct Student **head);   
void modify(struct Student **head); 
void find(struct Student *head);    
int modify_menu();
int main()
{
	struct Student *head = NULL;
	int x;
	do
	{
	
		printf("                                          \n");
		printf("    1 ����ѧ��          2 ɾ��ѧ��        \n");
		printf("                                          \n");
		printf("    3 �޸�����          4 ����ѧ��        \n");	
		printf("                                          \n");	
		printf("����������Ҫʹ�õĹ���\n");
		scanf("%d",&x);
		switch(x)
		{
			case 1 :
				insert(&head);
				break;
			case 2 :
				dele(&head);
				break;
			case 3 :
				modify(&head);
				break;
			case 4 :
				find(head);
				break;
			case 5 :
				print(head);
				break;
			default :
					printf ("ѡ����󣡣���\n");
					break;
		}
	}while(x);
}
void insert(struct Student **head)
{
	FILE*fp; 
	fp=fopen("D:\cxlx\C\stuInfo.txt","a+");
	struct Student *p = (struct Student*)malloc(sizeof(struct Student));
	struct Student *stu=NULL;
	printf("num:");
	scanf("%d",&(p->num));
	printf("name:");
	scanf("%s",(p->name));
	printf("sex:");
	scanf("%s",(p->sex));
	printf("age:");
	scanf("%d",&p->age);
	printf("depart:");
    scanf("%s",(p->name));
	p->next=NULL;
	if(*head == NULL)
    {
        *head = p;
    }
    else
    {
        stu = *head;
        while(stu->next != NULL)
        {
            stu = stu->next;
        }
        stu->next = p;
    }
}
void print(struct Student *head)
{
	FILE*fp; 
	fp=fopen("D:\cxlx\C\stuInfo.txt","a+");
	printf("ѧ��       ����       �Ա�   ����       Ժϵ \n");
	while(head != NULL)
	{
	printf("%5d  %10s      %s       %d        %10s\n",head->num,head->name,head->sex,head->age);
	head=head->next;
	}
}
void dele(struct Student **head)
{

	char arr1[20];
	struct Student *p1 = NULL;
	struct Student *p2 = *head;
	printf("������Ҫɾ����ѧ��\n");
	scanf("%s",arr1);
	FILE*fp; 
	fp=fopen("D:\cxlx\C\stuInfo.txt","r");
	while(p2 != NULL)
	{
		if(p1==NULL&&strcmp(arr1,p2->name)==0)
		{
			*head = p2->next;
			free(p2);
			break ;
		}
		else if(strcmp(arr1,p2->name)==0)
		{
			p1->next = p2->next;
			free(p2);
			break ; 
		}
		p1=p2;
		p2=p2->next;
	}
	print(*head);
	
}
void modify(struct Student **head)  
{
	char arr[20];
	int x = 0;
	struct Student *p = *head;
		FILE*fp; 
	fp=fopen("D:\cxlx\C\stuInfo.txt","r");
	printf("��������Ҫ�޸����ϵ�����\n");
	scanf("%s",arr);
	
	while(p!=NULL)
	{
		if(strcmp(arr,p->name) ==0)
		{
			printf("��ѡ���޸ĵ�����\n");
			x = modify_menu();
			printf("�������µ�����\n");
			switch(x)
			{
			case 1 :
				scanf("%d",&p->num);
				break;
			case 2 :
				scanf("%s",p->name);
				break;
			case 3 :
				scanf("%s",p->sex);
				break;
			case 4:
				scanf("%d",&p->age);
				break;
			case 5:
				scanf("%d",p->depart);
				break;
			default :
					printf ("ѡ����󣡣���\n");
					break;
			}
		print(*head);
		break ;
		}	
	p=p->next;
	}
}
int modify_menu()   
{
    int choose = 0;
    printf ("*    1  ѧ��        2  ����       *\n");
    printf ("*    3  �Ա�        4  ����       *\n");
    printf ("*	  5  Ժϵ                  *\n");
    scanf ("%d", &choose);
    return choose;
}
void find(struct Student *head)
{
		FILE*fp; 
	fp=fopen("D:\cxlx\C\stuInfo.txt","r");
	char arr[20];
	printf("������ѧ������\n");
	scanf("%s",arr);
	while(head!=NULL)
	{
		if(strcmp(arr,head->name)==0)
		{
			printf("ѧ��       ����       �Ա�   ����      Ժϵ \n");
			printf("%5d  %10s      %s       %d       %10s\n",head->num,head->name,head->sex,head->age,head->depart);
		}
	head=head->next;
	}
}


