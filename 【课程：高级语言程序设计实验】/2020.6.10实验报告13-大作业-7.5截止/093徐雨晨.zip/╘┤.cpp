#include<stdio.h>
#include<stdlib.h>
struct studentdata
{
    int num;
    char name[20];
    char sex[10];
    int age;
    char yuanxi[20];
};
struct Node
{
    studentdata data;
    struct Node* next;
};
Node* creathead() {
    Node* p;
    p = (Node*)malloc(sizeof(Node));
    if (p == NULL)
        printf("����ʧ��");
    p->next = NULL;
    return p;
}
Node* creatnewnode(struct studentdata data) {
    Node* newnode = (Node*)malloc(sizeof(Node));
    newnode->data = data;
    newnode->next = NULL;
    return newnode;
}
void Sort(Node* head)
{
    Node* p, * q, * end;
    end = NULL;
    while ((head->next->next) != end)
    {
        p = head;
        q = head->next;
        while (q->next != end)
        {
            if ((q->data.num) < (q->next->data.num))
            {
                p->next = q->next;
                q->next = q->next->next;
                p->next->next = q;
                q = p->next;
            }
            q = q->next;
            p = p->next;
        }
        end = q;
    }
}
Node* findnode(Node* head, int num) {
    Node* temp = head->next;
    while (temp) {
        if (temp->data.num == num) {
            return temp;
        }
        temp->next;
    }
    return NULL;
}
void deletenode(Node* head, int num) {
    int i;
    Node* p, * q;
    p = head;
    i = 1;
    while (i < num)
    {
        p = p->next;
        i++;
    }
    q = p->next;
    p->next = p->next->next;
    free(q);
}
int menu() {
    int i = 0;
    printf(" ");
    printf(" 0.�˳�ϵͳ ");
    printf(" 1.¼����Ϣ ");
    printf(" 2.ɾ����Ϣ ");
    printf(" 3.������Ϣ ");
    printf(" ������ ");
    scanf("%d", &i);
    return i;
}
int main() {
    Node* head;
    int i = 0, k = 0;
    studentdata data;
    head = creathead();
    studentinfo(head);
    system("cls");
    do {
        i = menu();
        switch (i) {
        case 0:break;
        case 1:printf("������ѧ����Ϣ:\tѧ��\t����\t�Ա�\t����\tԺϵ\t");
            scanf("%d%s%s%d%s", &data);
            creatnewnode(data);
            sort(head);
            break;
        case 2:printf("��������Ҫɾ��ѧ����ѧ��");
            scanf("%d", &k);
            deletenode(head, k);
            break;
        case 3:printf("��������Ҫ����ѧ����ѧ��");
            scanf("%d", &k);
            deletenode(head, k);
            break;
        default:printf("�������");
        }
    } while (i);
    return 0;
}