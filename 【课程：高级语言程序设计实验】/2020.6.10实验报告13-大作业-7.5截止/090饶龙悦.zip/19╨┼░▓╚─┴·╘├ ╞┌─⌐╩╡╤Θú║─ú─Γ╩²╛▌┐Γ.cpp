#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>//���ַ����ú�����
#include <string.h>
#include <windows.h>
#include <time.h>
#include <locale.h>//���ñ�������
typedef struct Studentdate
{
	int id;
	char name[30];
	char gender;
	int age;
	char faculty;
}SD;
typedef struct Classdate
{
	int number;
	char name;
	char pcourse;
	int credit;
}CD;
typedef struct Studentclass
{
	int id;
	int number;
	int record;
}SC;
int menu();
int InputSore1(SD sd[],SC sc[],int n);
int InputSore2(CD cd[],int e);
void DelSore1(SD sd[],SC sc[],int n);
void DelSore2(CD cd[],int e);
void Modify1(int n,SD sd[]);
void Modify2(CD cd[],int e);
void Modify3(SC sc[],int n);
void paixu1(SD sd[],int n);
void paixu2(int e,CD cd[]);
void paixu3(int n,SC sc[]);
void SavetoFile3(char *fname3,SC sc[],int n);
void SavetoFile2(char *fname2,CD cd[],int e);
void SavetoFile1(char *fname1,SD sd[],int n);
void wcharTochar(const wchar_t* wchar, char* chr, int length);
void PrintTable1(SD sd[],int n);
void PrintTable2(CD cd[],int e);
void PrintTable3(int n,SC sc[]);
int main()
{
	SD sd[1000];
	CD cd[50];
	SC sc[10000];
	char sex[2]={'F','M'};
	char faculty[3]={'A','B','C'};
	wchar_t name1[20];
	char name[10]={'A','B','C','D','E','F','G','H','I','J'};
	char pcourse[10]={'a','b','c','d','e','f','g','h','i','j'};
	int record[5]={95,90,85,80,75};
	int age[3]={18,19,20};
	int num;
    int i,j,n=10,a,b,c,k,f,i1,m,p,q,h,len1,len2,e=10,d;
    double start,end,time11;
    char name2[20];
    wchar_t xing[] = L"��Ǯ��������֣�����������������������";
    wchar_t ming[] = L"������󿡲���˼־Ⱥ��������ǿ·����η����������γ�������Ȼ�ľ�����������Դ·"; 
	char fname1[32];
	char fname2[32];
	char fname3[32];               
    srand(time(NULL));
    for (i=0;i<n;i++)//�����һ 
    {
    	num = rand() % 2;  
		k = rand() % 6 + 17;  
		f=rand()%3;
		sd[i].id = i + 1;
		sd[i].gender = sex[num];  
		sd[i].age = k;
		sd[i].faculty = faculty[f];
		b=rand()%20;
		name1[0]=xing[b];//���������������
		for(a=1;a<3;a++)//���������������
		{
			c=rand()%40;
			name1[a]=ming[c];
		}
     	name1[a]='\0';
     	wcharTochar(name1, name2, sizeof(name2));
     	setlocale(LC_ALL,"chs");//����Ϊ�������
     	strcpy(sd[i].name,name2);
    }
    for(i=0;i<10;i++)//���ɱ�2 
    {
    	m = rand()%3+3;
    	cd[i].number=i;
    	cd[i].credit=m;
    	cd[i].name=name[i];
    	cd[i].pcourse=pcourse[i];
	}
	for(i=0;i<n;i++)//���ɱ�3
	{
		q=rand()%10;
		p=rand()%5;
		sc[i].id=i;
		sc[i].number=cd[q].number;
		sc[i].record=record[p];	
	} 
	PrintTable1(sd,n);
	PrintTable2(cd,e);
	PrintTable3(n,sc);
	printf("Press any key to enter the menu page.");
	system("pause");
    system("cls");
    do
	{
    	h=menu();
    	switch(h)
		{	
			case 0:break;
			case 1:
				start = clock();
				{
					printf("To add Table 1 input 1, add Table 2 input 2:\n");
					scanf("%d",&j);
					if(j==1)
					{
						len1=InputSore1(sd,sc,n);
						n=n+len1;
						paixu1(sd,n);
						paixu3(n,sc);
					}
					if(j==2)
					{
						len2=InputSore2(cd,e);
						e=e+len2;
						paixu2(e,cd);
					}
					else
					{
						printf("Please input as required!"); 
					}
					end = clock();
					time11 = (double)((end - start) * 1000) / CLOCKS_PER_SEC;
					printf("time1=%lfms\n", time11); 
					break;
				}
			case 2:
				{
					printf("To delete Table 1 input 1, delete Table 2 input 2:\n");
					scanf("%d",&j);
					if(j==1)
					{
						DelSore1(sd,sc,n);
						n=n-1;
					}
					if(j==2)
					{
						DelSore2(cd,e);
						e=e-1;
					}
					break;
				} 
			case 3:
				{
					printf("To modify table 123, enter 123:\n");
					scanf("%d",&j);
					if(j==1)
					{
						Modify1(n,sd);
					}
					if(j==2)
					{
						Modify2(cd,e);
					}
					if(j==3)
					{
						Modify3(sc,n);
					} 
					break;
				}
			case 4:
				{
					printf("Input 123 to generate files 123:\n");
					scanf("%d",&j);
					if(j==1)
					{
						printf("The saved file name 1 is:");
						scanf("%s",&fname1); 
						SavetoFile1(fname1,sd,n);break;
					}
					if(j==2)
					{
						printf("The saved file name 2 is:");
						scanf("%s",&fname2);
						SavetoFile2(fname2,cd,e);
					}
					if(j==3)
					{
						printf("The saved file name 3 is:");
						scanf("%s",&fname3);
						SavetoFile1(fname1,sd,n);
					}
					break;
				}
			case 5:	
			{
				start = clock();
				printf("To check table 1, enter 1, table 2, enter 2,table 3,enter 3:\n");
				scanf("%d",&j);
				if(j==1)
				{
					printf("Enter student ID to query student information:\n");
					scanf("%d",&d);
					for(i=0;i<n;i++)
					{
						if(sd[i].id==d)
						{
							end = clock();
							printf("The information of the inquired students is:\n");
							printf("%-10d%-10s%-10c%-10d%-10c\n",sd[i].id,sd[i].name,sd[i].gender,sd[i].age,sd[i].faculty);
							time11 = (double)((end - start) * 1000) / CLOCKS_PER_SEC;
							printf("time1=%lfms\n", time11);
							break;
						}
					}
				}
				if(j==2)
				{
					printf("Enter course number to query course information:\n");
					scanf("%d",&d);
					for(i=0;i<e;i++)//e=10
					{
						if(cd[i].number==d)
						{
							printf("The course information queried is:\n");
							printf("%-10d%-10c%-10c%-10d\n",cd[i].number,cd[i].name,cd[i].pcourse,cd[i].credit);
							break;
						}
					} 
				}
				if(j==3)
				{
					printf("Enter student ID to query student course information:\n");
					scanf("%d",&d);
					for(i=0;i<n;i++)
					{
						if(sc[i].id==d)
						{
							printf("The information of the inquired student course is:\n");
							printf("%-10d%-10d%-10d\n",sc[i].id,sc[i].number,sc[i].record);
							break;
						}
					}
				}
				break;
			}
	 	}
	 	system("pause");
	 	system("cls");
	} while(h);
	return 0;
}
int menu()//�����˵� 
{
	int n=0;
	printf("********************\n");
	printf("1.Add data: \n"); 
	printf("2.Delete data: \n");
	printf("3.Modify data: \n");
	printf("4.Generate text file: \n");
	printf("5.Display data: \n");
	printf("0.Quit: \n"); 
	printf("********************\n");
	printf("Please select: ");
	scanf("%d",&n);
	return n;
}
int InputSore1(SD sd[],SC sc[],int n)//����ѧ����Ϣ 
{
	int i,j,m,k; 
	printf("Please input the number of new students:\n");
	scanf("%d",&m);
	for(i=n;i<n+m;i++)//����1 
	{
		printf("Enter student's name, gender, age, Department:/n"); 
		scanf("%d",&sd[i].id);
		scanf("%s",sd[i].name);
		scanf("%c",&sd[i].gender);
		scanf("%d",&sd[i].age);
		scanf("%c",&sd[i].faculty);
	}
	for(i=n;i<n+m;i++)//����3 
	{
		printf("Enter the course and grade of the new student:\n");
		sc[i].id=sd[i].id;
		scanf("%d",&sc[i].number);
		scanf("%d",&sc[i].record);
	} 
	printf("Add complete.");	
	return(m);
} 
int InputSore2(CD cd[],int e)//���ӱ�2 
{
	int i,k;
		printf("Please enter the number of new courses:\n");
		scanf("%d",&k);
		for(i=e;i<e+k;i++)
		{
			printf("Enter course name, advanced course, credit:\n");
			cd[i].number=i;
			scanf("%s",&cd[i].name);
			scanf("%c",&cd[i].pcourse);
			scanf("%d",&cd[i].credit);
		} 
		printf("Add complete.");
		return(k);
}
void DelSore1(SD sd[],SC sc[],int n)//ɾ��ѧ����Ϣ 
{
	int m,i;
	printf("Enter student ID to delete:\n");
	scanf("%d",&m);
	for(i=0;i<n;i++)//ɾ����1 
	{
		if(sd[i].id==m)
		{
			for(;i<n-1;i++)
			{
				sd[i]=sd[i+1];
			}
		}
	}
	for(i=0;i<n;i++)
	{
		if(sc[i].id==m)
		{
			for(;i<n-1;i++)
			{
				sc[i]=sc[i+1];
			}
		}
	}
	printf("Delete complete");
} 
void DelSore2(CD cd[],int e)//ɾ����2���� 
{
	int m,i;
	printf("Please enter the course number of the course to be deleted:\n");
	scanf("%d",&m);
	for(i=0;i<e;i++)
	{
		if(cd[i].number==m)
		{
			for(;i<e-1;i++)
			{
				cd[i]=cd[i+1];
			}
		}
	} 
	printf("Delete complete");
}
void Modify1(int n,SD sd[])//�ı�1 
{
	int i,m;
	printf("Enter the student ID of the student you want to modify:\n");
	scanf("%d",m);
	for(i=0;i<n;i++)
	{
		if(sd[i].id==m)
		{
			printf("Modify name:\n");
			scanf("%s",sd[i].name);
			printf("Modify gender��\n");
			scanf("%s",&sd[i].gender);
			printf("Modify age:\n");
			scanf("%d",&sd[i].age);
			printf("Modify Department:\n");
			scanf("%s",&sd[i].faculty);
			printf("The revised student information is:\n"); 
			printf("%-10d%-10s%-10c%-10d%-10c",sd[i].id,sd[i].name,sd[i].gender,sd[i].age,sd[i].faculty);
		}
		else
		{
			printf("No one��"); 
		} 
	}
}
void Modify2(CD cd[],int e)//�ı�2 
{
	int m,i;
	printf("Please enter the course number of the course you want to modify:\n");
	scanf("%d",&m);
	for(i=0;i<e;i++)
	{
		if(cd[i].number==m)
		{
			printf("Modify course name:\n");
			scanf("%s",&cd[i].name);
			printf("Modify antecedent:\n");
			scanf("%s",&cd[i].pcourse);
			printf("Modify credit:\n");
			scanf("%s",&cd[i].credit);
			printf("The modified course information is:\n");
			printf("%-10d%-10s%-10c%-10d",cd[i].number,cd[i].name,cd[i].pcourse,cd[i].credit);
			
		}
		else
		{
			printf("No such course��"); 
		}
	}
} 
void Modify3(SC sc[],int n)//�ı�3 
{
	int m,i;
	printf("Input the student number to be modified:\n");
	scanf("%d",&m);
	for(i=0;i<n;i++)
	{
		if(sc[i].id==m)
		{
			printf("Revise the course(Course number):\n");
			scanf("%d",&sc[i].number);
			printf("Revise student grades:\n");
			scanf("%d",&sc[i].record);
			printf("The revised student course information is:\n");
			printf("%-10d%-10d%-10d",sc[i].id,sc[i].number,sc[i].record);
		}
		else
		{
			printf("No one!");
		}
	}
}
void paixu1(SD sd[],int n)
{
	int i,j;
	SD sd1;
	for(i=1;i<n;i++)
	{
		for(j=n-1;j>=i;i--)
		{
			if(sd[j].id<sd[j-1].id)
			{
				sd1=sd[j-1];
				sd[j-1]=sd[j];
				sd[j]=sd1;
			}
		}
	}
}
void paixu2(int e,CD cd[])
{
	int i,j;
	CD cd1;
	for(i=1;i<e;i++)
	{
		for(j=e-1;j>=i;i--)
		{
			if(cd[j].number<cd[j-1].number)
			{
				cd1=cd[j-1];
				cd[j-1]=cd[j];
				cd[j]=cd1;
			}
		}
	}
}
void paixu3(int n,SC sc[])
{
	int i,j;
	SC sc1;
	for(i=1;i<n;i++)
	{
		for(j=n-1;j>=i;j--)
		{
			if(sc[j].id<sc[j-1].id)
			{
				sc1=sc[j-1];
				sc[j-1]=sc[j];
				sc[j]=sc1;
			}
		}
	}
} 
void SavetoFile1(char *fname1,SD sd[],int n)
{
	FILE *fp;
	int i;
	if((fp=fopen(fname1,"w"))==NULL)
	{
		printf("Failed to open file!");
		exit(0);
	}
	for(i=0;i<n;i++)
	{
		fprintf(fp,"%5d%5s%5c%5d%5c",sd[i].id,sd[i].name,sd[i].gender,sd[i].age,sd[i].faculty);
	}
	fclose(fp);
}
void SavetoFile2(char *fname2,CD cd[],int e)
{
	FILE *fp;
	int i;
	if((fp=fopen(fname2,"w"))==NULL)
	{
		printf("Failed to open file!\n");
		exit(0);
	}
	for(i=0;i<e;i++)
	{
		fprintf(fp,"%10d%10c%10c%10d",cd[i].number,cd[i].name,cd[i].pcourse,cd[i].credit);
	}
	fclose(fp);
}
void SavetoFile3(char *fname3,SC sc[],int n)
{
	FILE *fp;
	int i;
	if((fp=fopen(fname3,"w"))==NULL)
	{
		printf("Failed to open file!\n");
		exit(0);
	}
	for(i=0;i<n;i++)
	{
		fprintf(fp,"%10d%10d%10d",sc[i].id,sc[i].number,sc[i].record);
	}
	fclose(fp);
}
void wcharTochar(const wchar_t* wchar, char* chr, int length)
{
	WideCharToMultiByte(CP_ACP, 0, wchar, -1, chr, length, NULL, NULL);
}
void PrintTable1(SD sd[],int n)
{
	int i;
	printf("Student number    gender    age     Student name     Department\n");
	printf("********************************************************************\n");
	for (i = 0;i < n;i++)
	{
		printf("%2d%13s%16c%16d%14c\n", sd[i].id, sd[i].name, sd[i].gender, sd[i].age,sd[i].faculty);
	}
}
void PrintTable2(CD cd[],int e)
{
	int i;
	printf("Course number     Course name      Antecedent course     credit\n");
	printf("**************************************************************\n");
	for (i = 0;i < e;i++)
	{
		printf("%2d%13c%16c%16d\n", cd[i].number, cd[i].name, cd[i].pcourse, cd[i].credit);
	}
}
void PrintTable3(int n,SC sc[])
{
	int i;
	printf("Student number    Course number     Test Scores\n");
	printf("************************************************\n");
	for(i=0;i<n;i++)
	{
		printf("%2d%13d%16d%\n",sc[i].id,sc[i].number,sc[i].record);
	}
}

