#include "state.h"
int main() {
	struct Stu *head1 = NULL;
	struct Les *head2 = NULL;
	struct Grad *head3 = NULL;
	int dis;
	double endtime;
	double t1,t2,t3,t4,t5,t6,t7,t8;//���ڼ�ʱ 
	double time1,time2,time3,time4;//�������ռ�¼ʱ�� 
	time1 = time2 = time3 = time4 = 0;
	
	head1 = setlist1();
	head2 = setlist2();
	head3 = setlist3(head1,head2);//Ϊ����һ��ѧ�������������Ŀγ̽����ɼ� 
	
	printf("Now there are %d students' information, %d coures' information, %d students' grade information.\n\n",STUNUM,COURSE,GRADE);
	print();
	
	while(scanf("%d",&dis) == 1){
		switch(dis){
			case 1:{//add
				t1 = clock();
				add(head1,head2,head3);//���㣺���û��Ȱ����ݶ�ɾ��������������� 
				t2 = clock();
				time1 = (time1 + t2-t1)/1000;
				system("pause");
				break;
			}
			case 2:{//delete
				t3 = clock();
				int dis2;
				printf("Delete information in list 1: input 1\nDelete information in list 2: input 2\nDelete information in list 3: input 3\n");	
				scanf("%d",&dis2);
				switch(dis2){//��ѡ��ɾ�����б�����ɾ�������Ժ��������Ϣ���б�Ҳ����ɾ�� //���㣺û����ʾ�����Ƿ���ڣ���û����ʾ�����󵽵������Ǳ�ɾ�����ǲ����� 
					case 1: {
						long num;
						int dis;
						dis = 0;
						printf("Please input student number:");
						scanf("%ld",&num);
						head1 = dellist1(head1,num,&dis);
						head3 = dellist3_1(head3,num);
						t4 = clock();
						time2 = (time2 + t4-t3)/1000;
						if( dis ){
							printf("The information was deleted.\n");
						}else{
							printf("The information was not here.\n");
						}
						system("pause");
						break;
					}
					case 2: {
						int num;
						int dis;
						dis = 0;
						printf("Please input the course number:\n");
						scanf("%d",&num);
						head2 = dellist2(head2,num,&dis);
						head3 = dellist3_2(head3,num);
						t4 = clock();
						time2 = (time2 + t4-t3)/1000;
						if( dis ){
							printf("The information was deleted.\n");
						}else{
							printf("The information was not here.\n");
						}
						system("pause");
						break;
					}
					case 3: {
						long num;
						int num2,dis;
						dis = 0;
						printf("Please input the student numer and the course number:\n");
						scanf("%ld %d",&num,&num2);
						head3 = dellist3(head3,num,num2,&dis);
						t4 = clock();
						time2 = (time2 + t4-t3)/1000;
						if( dis ){
							printf("The information was deleted.\n");
						}else{
							printf("The information was not here.\n");
						}
						system("pause");
						break;
					}
					default: printf("The number is invalid\n");
							 printf("Please input right number\n");
							 system("pause");
							 break;
				}
				break;
			}
			case 3:{//alter
				long num;
				printf("Please input the student number:\n");
				t5 = clock();
				scanf("%ld",&num);
				alt(head1,num);
				t6 = clock();
				time3 = ( time3 + t6-t5 )/1000;
				system("pause");
				break;
			}
			case 4:{//find
				int n;
				printf("Search student information by the student number: input 1\nSearch student information by the student name: enter 2\n");
				t7 = clock();
				scanf("%d",&n);//����2.3ʱ������������� ��scanf��������˽ض� 
				fin(head1,n);
				t8 = clock();
				time4 = ( time4 + t8-t7 )/1000;
				system("pause");
				break;
			}
			default:printf("The number is invalid.\n");
					printf("Please input the right number.\n");
					system("pause");
					break;
		}
		
		for( endtime = 5; endtime >= 0; endtime -= 1){
			printf("The screen is going to be flushed after %1.0f seconds.\b\b\b\b\b\b\b\b\b\b",endtime);
        	sleep(1);
			printf("\r");
    	}
    	printf("\n����ʱ������");
    	sleep(1);
		system("cls");
		sleep(1);
		print();
	}
	
	for( endtime = 5; endtime >= 0; endtime -= 1){
		printf("The screen is going to be flushed after %1.0f seconds.\b\b\b\b\b\b\b\b\b\b",endtime);
        sleep(1);
		printf("\r");
    }
    printf("\n����ʱ������");
    sleep(1);
	system("cls");
	sleep(1);
	printf("The program takes %.3f seconds to add information, %.3f seconds to delete information,\n%.3f seconds to alter information, %.3f seconds to find information.\n",time1,time2,time3,time4);
	
	write(head1,head2,head3);//�����ļ� 
	printf("\nThe data is recored.\nYou can open the file to read them.\nThe program is over.\n");
	fre(head1,head2,head3);//�ͷſռ� 
	
	return 0;
}
