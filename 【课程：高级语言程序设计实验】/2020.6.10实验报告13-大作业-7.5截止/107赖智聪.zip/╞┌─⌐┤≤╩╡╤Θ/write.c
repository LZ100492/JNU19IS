#include "state.h"
void write(struct Stu *head1, struct Les *head2, struct Grad *head3){
	struct Stu *p = head1;
	struct Les *q = head2;
	struct Grad *r = head3;
	FILE *p1,*p2,*p3;
	
	if( (p1 = fopen("list_1.txt","w")) == NULL ){
		printf("Open list_1.txt fail.\n");
	}else{
		fprintf(p1,"ѧ��\t\t����\t�Ա�\t����\tԺϵ\n");
		while( p != NULL ){
			fprintf(p1,"%ld\t%s\t%c\t%d\t%s\n",p->stu_num,p->name[0],p->sex,p->age,p->sch[0]);
			p = p->next;
		}
	}
	p = NULL;
	fclose(p1);
	
	if( (p2 = fopen("list_2.txt","w")) == NULL ){
		printf("Open list_2.txt fail.\n");
	}else{
		fprintf(p2,"�γ̺�\t�γ���\t���п�\tѧ��\n");
		while( q != NULL ){
			fprintf(p2,"%d\t%s\t%s\t%d\n",q->cou_num,q->lesname[0],q->firstles[0],q->credit);
			q = q->next;
		}
	}
	q = NULL;
	fclose(p2);
	
	if( (p3 = fopen("list_3.txt","w")) == NULL ){
		printf("Open list_3.txt fail.\n");
	}else{
		fprintf(p3,"ѧ��\t\t�γ̺�\t�ɼ�\n");
		while( r != NULL ){
			fprintf(p3,"%d\t%d\t%d\n",r->stu_num,r->cou_num,r->grade);
			r = r->next;
		}
	}
	r = NULL;
	fclose(p3);
}
