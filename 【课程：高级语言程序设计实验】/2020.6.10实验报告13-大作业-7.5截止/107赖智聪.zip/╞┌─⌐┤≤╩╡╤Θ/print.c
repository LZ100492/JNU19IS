#include "state.h"
void print(){
	printf("Choice:\n");
	printf("Add information: input 1\n");
	printf("Delete information: input 2\n");
	printf("Alter information: input 3\n");
	printf("Find information: input 4\n");
	printf("Else: enter end to finish the program\n");
}
