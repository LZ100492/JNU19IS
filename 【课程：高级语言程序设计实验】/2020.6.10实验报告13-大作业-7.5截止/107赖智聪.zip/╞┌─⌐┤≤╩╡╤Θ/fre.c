#include "state.h"
void fre(struct Stu *head1, struct Les *head2, struct Grad *head3){
	void freelist1(struct Stu *head);
	void freelist2(struct Les *head);
	void freelist3(struct Grad *head);
	freelist1(head1);
	freelist2(head2);
	freelist3(head3);
}
void freelist1(struct Stu *head){
	struct Stu *p,*q;
	p = q = head;
	while( p != NULL ){
		q = q->next;
		free(p->name[0]);
		free(p->sch[0]);
		free(p);
		p = q;
	}
}
void freelist2(struct Les *head){
	struct Les *p,*q;
	p = q = head;
	while( p != NULL ){
		q = q->next;
		free(p->firstles[0]);
		free(p->lesname[0]);
		free(p);
		p = q;
	}
}
void freelist3(struct Grad *head){
	struct Grad *p,*q;
	p = q = head;
	while( p != NULL){
		q = q->next;
		free(p);
		p = q;
	}
}
