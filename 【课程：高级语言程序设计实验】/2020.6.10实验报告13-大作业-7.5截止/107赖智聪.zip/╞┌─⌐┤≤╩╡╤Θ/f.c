#include "state.h"
void add(struct Stu *head1, struct Les *head2, struct Grad *head3){
	int judge;
	printf("Input 1 to add information to the student\nInput 2 to add information to the course\nInput 3 to add information to the grade\n");
	scanf("%d",&judge);
	switch(judge){
		case 1:{
			struct Stu *p,*q;
			p = head1;
			q = NULL;
			while( p->next != NULL){
				p = p->next;
			}
			printf("Now the largest student number is %d.\n",p->stu_num);
			printf("Please input the student number from small to large, name(at most 4 Chinese characters), gender( F or M), age, academy(at most 6 Chinese characters).\nInput -1 mean to end your input:\n");//printf("%ld %s %c %d %s\n",p->stu_num,p->name[0],p->sex,p->age,p->sch[0]); 
			q = (struct Stu *) malloc( sizeof(struct Stu) );
			q->name[0] = (char *) malloc(9*sizeof(char));//������֮һ��û�м�������������ѧԺ���ĳ��� 
			q->sch[0] = (char *) malloc(13*sizeof(char));
			scanf("%ld",&q->stu_num);
			while(  q->stu_num != -1 ){
				scanf("%s %c %d %s",q->name[0],&q->sex,&q->age,q->sch[0]);
				if(q->stu_num <= p->stu_num){//���ѧ�Ŵ����Ƿ���ȷ
					printf("The student number order is wrong! Now the final data is invalid, it will be thrown away.\n");
					printf("Because the number you inputed is not right, the input is over!\n");
					break;
				}
				p->next = q;
				p = q;
				q = (struct Stu *) malloc( sizeof(struct Stu) );
				q->name[0] = (char *) malloc(9*sizeof(char));
				q->sch[0] = (char *) malloc(13*sizeof(char));
				scanf("%ld",&q->stu_num);
			}
			p->next = NULL;
			free(q->name[0]);
			free(q->sch[0]);
			free(q);
			q = NULL;
			p = NULL;
			break;
		}
		case 2:{
			struct Les *p,*q;
			p = head2;
			q = NULL;
			while( p->next != NULL){
				p = p->next;
			}
			printf("Now the largest course number is %d.\n",p->cou_num);
			printf("Please input the course number from small to large, course number(at most 4 Chinese characters), the first class(at most 4 Chinese characters)\nand credit(1 or 2 or 3 or 4 or 5).\nInput -1 mean to end your input:\n");//���㣺û�ж�ѧ�ֽ��м��,û�м��������ַ����� 
			q = (struct Les *) malloc( sizeof(struct Les) );
			q->lesname[0] = (char *) malloc(10*sizeof(char));
			q->firstles[0] = (char *) malloc(10*sizeof(char));
			scanf("%d",&q->cou_num);
			while( q->cou_num != -1){
				scanf("%s %s %d",q->lesname[0],q->firstles[0],&q->credit);
				if(q->cou_num <= p->cou_num){
					printf("The course number order is wrong! Now the final data is invalid, it will be thrown away.\n");
					printf("Because your input is not right, the input is over!\n");
					break;
				}
				p->next = q;
				p = q;
				q = (struct Les *) malloc( sizeof(struct Les) );
				q->lesname[0] = (char *) malloc(10*sizeof(char));
				q->firstles[0] = (char *) malloc(10*sizeof(char));
				scanf("%d",&q->cou_num);
			}
			p->next = NULL;
			free(q->firstles[0]);
			free(q->lesname[0]);
			free(q);
			q = NULL;
			p = NULL;
			break;
		}
		case 3:{ 
			struct Grad *p,*q;
			p = head3;
			while( p->next != NULL){
				p = p->next;
			}
			printf("Now the largest student number is %d.\n",p->stu_num);
			printf("Please input the student number from small to large, course number and grade(from 0 to 100), all these must be integer.\nInput -1 mean to end your input:\n");
			q = (struct Grad *) malloc( sizeof(struct Grad) );
			scanf("%d",&q->stu_num);
			while( q->stu_num != -1){
				scanf("%d %d",&q->cou_num,&q->grade);//���㣺�������ѧ�źϷ����γ̺Ż��߳ɼ���������ʱ��������Ҳ����¼���� 
				if( q->stu_num < p->stu_num ){
					printf("Your input is wrong! Now the final data is invalid, it will be thrown away.\n");
					printf("Because your input is not right, the input is over!\n");
					break;
				}
				p->next = q;
				p = q;
				q = (struct Grad *) malloc( sizeof(struct Grad) );
				scanf("%d",&q->stu_num);
			}
			p->next = NULL;
			free(q);
			q = NULL;
			p = NULL;
			break;
		}
		default: printf("Your input is invalid.\n");break;
	}
}

struct Stu *dellist1(struct Stu *head1,const long num,int *dis){
	struct Stu *p,*q;
	p = head1, q = NULL;
	while( p != NULL ){
		if( p->stu_num == num ){
			*dis = 1;
			if( q == NULL){
				head1 = p->next;
			}else{
				q->next = p->next;
			}
			free(p);
			break;
		}else{
			q = p;
			p = p->next;
		}
	}
	p = q = NULL;
	return head1;		
}
struct Grad *dellist3_1(struct Grad *head3,const long num){
	struct Grad *p,*q;
	p = head3, q = NULL;
	while( p != NULL ){
		if( p->stu_num == num ){
			if( q == NULL){
				head3 = p->next;
			}else{
				q->next = p->next;
			}
			free(p);
			if( q == NULL){
				p = head3;
			}else{
				p = q->next;
			}
		}else{
			q = p;
			p = p->next;
		}
	}
	p = q = NULL;
	return head3;
}
struct Les * dellist2(struct Les *head2,const int num,int *dis){	
	struct Les *p,*q;
	p = head2, q = NULL;
	while( p != NULL){
		if( p->cou_num == num){
			*dis = 1;
			if( q == NULL ){
				head2 = p->next;
			}else{
				q->next = p->next;
			}
			free(p);
			break;
		}else{
			q = p;
			p = p->next;
		}
	}
	p = q = NULL;
	return head2;
}
struct Grad *dellist3_2(struct Grad *head3, const int num){
	struct Grad *p,*q;
	p = head3, q = NULL;
	while( p != NULL){
		if( p->cou_num == num){
			if( q == NULL){
				head3 = p->next;
			}else{
				q->next = p->next;
			}
			free(p);
			if( q ){
				p = q->next;
			}else{
				p = head3;
			}
		}else{
			q = p;
			p = p->next;
		}
	}
	p = q = NULL;
	return head3;
}
struct Grad * dellist3(struct Grad *head3, const long num, const int num2,int *dis){
	struct Grad *p,*q;
	p = head3;
	q = NULL;
	while( p != NULL ){
		if( p->stu_num == num && p->cou_num == num2){
			*dis = 1;
			if ( q ){
				q->next = p->next;
			}else{
				head3 = p->next;
			}
			free(p);
			if( q ){
				p = q->next;
			}else{
				p = head3;
			}
		}else{
			q = p;
			p = p->next;
		}
	}
	return head3;
}

void alt(struct Stu *head1, const long num){
	struct Stu *p = head1;
	int judge = 1;
	while( p != NULL ){
			if( p->stu_num == num){
				printf("Please input the name:\n");
				scanf("%s",p->name[0]); 
				printf("Please input student gender: F or M\n");
				scanf("\n%c",&p->sex);
				printf("Please input age:\n");
				scanf("%d",&p->age);
				printf("Please input academy:\n");
				scanf("%s",p->sch[0]);
				judge = 0;
				printf("The information is changed.\n");
				break;
			}
			p = p->next;
	}
	if( judge ){
		printf("The student nnumber is not here.\n");
	}
		p = NULL;
}

void fin(struct Stu *head1, const int n){
	struct Stu *p = head1;
	int judge = 1;//Ĭ���Ҳ���ѧ��
	if( n == 1){
		long num;
		printf("Please input the student number:");
		scanf("%ld",&num);
		while( p != NULL ){
			if( p->stu_num == num){
				printf("ѧ��:%d ����:%s �Ա�:%c ����:%d ѧԺ:%s\n",p->stu_num,p->name[0],p->sex,p->age,p->sch[0]);
				judge = 0;
				break;
			}
			p = p->next;
		}
		if( judge ){
			printf("The student number is not here.\n");
		}
	}else if( n == 2){
		char name[9];
		printf("Please input the name:\n");
		scanf("%s",name);
		while( p != NULL ){
			if( strcmp(p->name[0],name) == 0){
				printf("ѧ��:%d ����:%s �Ա�:%c ����:%d ѧԺ:%s\n",p->stu_num,p->name[0],p->sex,p->age,p->sch[0]);
				judge = 0;
				break;
			}
			p = p->next;
		}
		if( judge ){
			printf("The student number is not here.\n");
		}
	}else{
		printf("Your input is invalid, please input right number.\n");
	}
	p = NULL;
}
