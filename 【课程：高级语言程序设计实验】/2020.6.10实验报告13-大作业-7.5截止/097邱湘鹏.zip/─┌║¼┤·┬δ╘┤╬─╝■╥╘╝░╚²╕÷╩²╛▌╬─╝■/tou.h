struct Stu_info {
	int num;
	char name[10];
	char sex[3];
	int age;
	char depart[100];

} stu[2000];
struct Course_info{
	int num;
	char c_name[6];
	int credit;
	char prec_name[8];
}course[50];

struct Stu_cou{
	int  snum;
	int cnum;
	int grade;
}info[10000];
