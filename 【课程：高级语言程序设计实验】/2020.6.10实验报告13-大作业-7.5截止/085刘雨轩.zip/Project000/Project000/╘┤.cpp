#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<stdlib.h>
#include "stuhead.h"

int main() 
{
	while (1)
	{
		Menu();
		char ch = _getch();
		switch (ch)
		{
		case '1':
			InputStu();
			break;
		case '2':
			InputCou();
			break;
		case '3':
			SaveFile();
			break;
		case '4':
			PrintStu();
			break;
		case '5':
			PrintCou();
			break;
		case '6':
			FindStu();
			break;
		case '7':
			FindCou();
			break;
		case '8':
			DelStu();
			break;
		case '9':
			DelCou();
			break;
		case '10':
			ChanStu();
			break;
		case '11':
			ChanCou();
			break;
		case '0':
			return 0;
			break;
		default:
			printf("�����������������\n\n");
			system("pause");
			system("cls");
			break;
		}
	}
	return 0;
}

void Menu() 
{
	printf("----------------------������---------------------\n");
	printf("-------------------------------------------------\n");
	printf("*\t\t1.����ѧ����Ϣ\t\t\t*\n");
	printf("*\t\t2.���ӿγ���Ϣ\t\t\t*\n");
	printf("*\t\t3.������Ϣ\t\t\t*\n");
	printf("*\t\t4.��ӡѧ����Ϣ\t\t\t*\n");
	printf("*\t\t5.��ӡ�γ���Ϣ\t\t*\n");
	printf("*\t\t6.����ѧ����Ϣ\t\t\t*\n");
	printf("*\t\t7.���ҿγ���Ϣ\t\t\t*\n");
	printf("*\t\t8.ɾ��ѧ����Ϣ\t\t\t*\n");
	printf("*\t\t9.ɾ���γ���Ϣ\t\t\t*\n");
	printf("*\t\t10.�޸�ѧ����Ϣ\t\t\t*\n");
	printf("*\t\t11.�޸Ŀγ���Ϣ\t\t\t*\n");
	printf("*\t\t0.�˳�ϵͳ\t\t\t*\n");
	printf("-------------------------------------------------\n");
}

void InputStu() 
{
	Node1* pNewNode1 = (Node1*)malloc(sizeof(Node1));
	pNewNode1->pNext = NULL;
	Node1* p = g_pHead;
	while (g_pHead != NULL && p->pNext != NULL)
	{
		p = p->pNext;
	}
	if (g_pHead == NULL) 
	{
		g_pHead = pNewNode1;
	}
	else {
		p->pNext = pNewNode1;
	}
	printf("������������\n");
	scanf_s("%s", pNewNode1->stu.stuName, sizeof(pNewNode1->stu.stuName));
	printf("�������Ա�\n");
	scanf_s("%s", pNewNode1->stu.stuSex, sizeof(pNewNode1->stu.stuSex));
	printf("���������䣺\n");
	scanf_s("%d", &pNewNode1->stu.stuAge);
	printf("������ѧ�ţ�\n");
	scanf_s("%d", &pNewNode1->stu.stuNo);
	printf("������Ժϵ��\n");
	scanf_s("%s", &pNewNode1->stu.college, sizeof(pNewNode1->stu.college));
	printf("¼��ɹ�\n\n");
	system("pause");
	system("cls");
}

void PrintStu()
{
	system("cls");
	Node1* p = g_pHead;
	if (p == NULL)
	{
		printf("���޴���\n\n");
	}
	else 
	{
		printf("---------------------------------------ѧ����Ϣ------------------------------------------\n");
		printf("*\tѧ��\t*\t����\t*\t�Ա�\t*\t����\t*\tԺϵ\t*\n");
		printf("-----------------------------------------------------------------------------------------\n");
		while (p != NULL)
		{
			printf("*\t%d\t*\t%s\t*\t%s\t*\t%d\t*\t%s\t*\n",
				p->stu.stuNo,
				p->stu.stuName,
				p->stu.stuSex,
				p->stu.stuAge,
				p->stu.college
			);
			p = p->pNext;
			printf("-----------------------------------------------------------------------------------------\n");
		}
	}
	system("pause");
	system("cls");
}

void InputCou()
{
	Node2* pNewNode2 = (Node2*)malloc(sizeof(Node2));
	pNewNode2->pNext = NULL;
	Node2* p = g_pHead2;
	while (g_pHead2 != NULL && p->pNext != NULL)
	{
		p = p->pNext;
	}
	if (g_pHead2 == NULL)
	{
		g_pHead2 = pNewNode2;
	}
	else {
		p->pNext = pNewNode2;
	}
	printf("������γ�����\n");
	scanf_s("%s", pNewNode2->cou.cName, sizeof(pNewNode2->cou.cName));
	printf("���������пΣ�\n");
	scanf_s("%s", pNewNode2->cou.pCourse, sizeof(pNewNode2->cou.pCourse));
	printf("������γ̺ţ�\n");
	scanf_s("%d", &pNewNode2->cou.cNumber);
	printf("������ѧ�֣�\n");
	scanf_s("%d", &pNewNode2->cou.cScore);
	printf("¼��ɹ�\n\n");
	system("pause");
	system("cls");
}

void PrintCou()
{
	system("cls");
	Node2* p = g_pHead2;
	if (p == NULL)
	{
		printf("���޴˿�\n\n");
	}
	else
	{
		printf("---------------------------------------�γ���Ϣ------------------------------------------\n");
		printf("*\t�γ̺�\t*\t�γ���\t*\t���п�\t*\tѧ��\t*\n");
		printf("-----------------------------------------------------------------------------------------\n");
		while (p != NULL)
		{
			printf("\t\t\t* %ld\t\t\t%s\t\t%s\t\t%d\t\t\t*\n", 
				p->cou.cNumber,
				p->cou.cName,
				p->cou.pCourse,
				p->cou.cScore
				);
			p = p->pNext;
			printf("-----------------------------------------------------------------------------------------\n");
		}
	}
	system("pause");
	system("cls");
}

void SaveFile() 
{
	FILE* pFile;
	{
		pFile = fopen(".\\stuinfo.dat", "w");
		if (pFile == NULL)
		{
			printf("���ļ�ʧ�ܡ�\n");
			return;
		}
		Node1* p = g_pHead;
		while (p != NULL)
		{
			fprintf(pFile, "*\t%d\t*\t%s\t*\t%s\t*\t%d\t*\t%s\t*\n",
				p->stu.stuNo,
				p->stu.stuName,
				p->stu.stuSex,
				p->stu.stuAge,
				p->stu.college
			);
			p = p->pNext;
		}
		fclose(pFile);
	}
	{
		pFile = fopen(".\\couinfo.dat", "w");
		if (pFile == NULL)
		{
			printf("���ļ�ʧ�ܡ�\n");
			return;
		}
		Node2* p = g_pHead2;
		while (p != NULL)
		{
			fprintf(pFile, "\t\t\t* %ld\t\t\t%s\t\t%s\t\t%d\t\t\t*\n",
				p->cou.cNumber,
				p->cou.cName,
				p->cou.pCourse,
				p->cou.cScore
			);
			p = p->pNext;
		}
		fclose(pFile);
	}
	printf("����ɹ���\n");
	system("pause");
	system("cls");
}

void FindStu() 
{
	system("cls");
	int studentnumber;
	printf("������ѧ�ţ�");
	scanf("%d", &studentnumber);
	Node1* p = g_pHead;
	bool tNum = false;
	bool tStu = false;
	while (p != NULL)
	{
		if (studentnumber == p->stu.stuNo) 
		{
			if (!tNum)
			{
				printf("---------------------------------------ѧ����Ϣ------------------------------------------\n");
				printf("*\tѧ��\t*\t����\t*\t�Ա�\t*\t����\t*\tԺϵ\t*\n");
				printf("-----------------------------------------------------------------------------------------\n");
				tNum = true;
			}
			printf("*\t%d\t*\t%s\t*\t%s\t*\t%d\t*\t%s\t*\n",
				p->stu.stuNo,
				p->stu.stuName,
				p->stu.stuSex,
				p->stu.stuAge,
				p->stu.college
			);
			tStu = true;
			printf("-----------------------------------------------------------------------------------------\n");
		}
		p = p->pNext;
	}
	if (!tStu) {
		printf("δ�ҵ�\n\n");
	}
	system("pause");
	system("cls");
}

void FindCou()
{
	system("cls");
	int classNum;
	printf("������γ̺ţ�");
	scanf("%d", &classNum);
	Node2* p = g_pHead2;
	bool tNum2 = false;
	bool tCou = false;
	while (p != NULL)
	{
		if (classNum == p->cou.cNumber)
		{
			if (!tNum2)
			{
				printf("---------------------------------------�γ���Ϣ------------------------------------------\n");
		printf("*\t�γ̺�\t*\t�γ���\t*\t���п�\t*\tѧ��\t*\n");
		printf("-----------------------------------------------------------------------------------------\n");
				tNum2 = true;
			}
				printf("\t\t\t* %ld\t\t\t%s\t\t%s\t\t%d\t\t\t*\n",
					p->cou.cNumber,
					p->cou.cName,
					p->cou.pCourse,
					p->cou.cScore
				);
			tCou = true;
			printf("-----------------------------------------------------------------------------------------\n");
		}
		p = p->pNext;
	}
	if (!tCou) 
	{
		printf("δ�ҵ�\n\n");
	}
	system("pause");
	system("cls");
}

void ChanStu() 
{
	int studentnumber;
	printf("������ѧ�ţ�");
	scanf("%d", &studentnumber);
	Node1* p = g_pHead;
	bool tNum = false;
	bool tStu = false;
	while (p != NULL)
	{
		if (studentnumber == p->stu.stuNo) 
		{
			if (!tNum) 
			{
				printf("---------------------------------------ѧ����Ϣ------------------------------------------\n");
				printf("*\tѧ��\t*\t����\t*\t�Ա�\t*\t����\t*\tԺϵ\t*\n");
				printf("-----------------------------------------------------------------------------------------\n");
				tNum = true;
			}
			printf("*\t%d\t*\t%s\t*\t%s\t*\t%d\t*\t%s\t*\n",
				p->stu.stuNo,
				p->stu.stuName,
				p->stu.stuSex,
				p->stu.stuAge,
				p->stu.college
			);
			printf("��������ȷ��������\n");
			scanf_s("%s", p->stu.stuName, sizeof(p->stu.stuName));
			printf("��������ȷ���Ա�\n");
			scanf_s("%s", p->stu.stuSex, sizeof(p->stu.stuSex));
			printf("��������ȷ�����䣺\n");
			scanf_s("%d", &p->stu.stuAge);
			printf("��������ȷ��ѧ�ţ�\n");
			scanf_s("%d", &p->stu.stuNo);
			printf("��������ȷ��Ժϵ��\n");
			scanf_s("%s", &p->stu.college, sizeof(p->stu.college));
			tStu = true;
			printf("-----------------------------------------------------------------------------------------\n");
			printf("�޸ĳɹ�\n\n");
		}
		p = p->pNext;
	}
	if (!tStu) 
	{
		printf("�������\n\n");
	}
	system("pause");
	system("cls");
}

void ChanCou()
{
	int classNum;
	printf("������γ̺ţ�");
	scanf("%d", &classNum);
	Node2* p = g_pHead2;
	bool tNum2 = false;
	bool tCou = false;
	while (p != NULL)
	{
		if (classNum == p->cou.cNumber)
		{
			if (!tNum2) 
			{
				printf("---------------------------------------�γ���Ϣ------------------------------------------\n");
				printf("*\t�γ̺�\t*\t�γ���\t*\t���п�\t*\tѧ��\t*\n");
				printf("-----------------------------------------------------------------------------------------\n");
				tNum2 = true;
			}
			printf("\t\t\t* %ld\t\t\t%s\t\t%s\t\t%d\t\t\t*\n",
				p->cou.cNumber,
				p->cou.cName,
				p->cou.pCourse,
				p->cou.cScore
			);
			printf("��������ȷ�Ŀγ�����\n");
			scanf_s("%s", p->cou.cName, sizeof(p->cou.cName));
			printf("��������ȷ�����пΣ�\n");
			scanf_s("%s", p->cou.pCourse, sizeof(p->cou.pCourse));
			printf("��������ȷ�Ŀγ̺ţ�\n");
			scanf_s("%d", &p->cou.cNumber);
			printf("��������ȷ��ѧ�֣�\n");
			scanf_s("%d", &p->cou.cScore);
			tCou = true;
			printf("-----------------------------------------------------------------------------------------\n");
			printf("�޸ĳɹ�\n\n");
		}
		p = p->pNext;
	}
	if (!tCou)
	{
		printf("�������\n\n");
	}
	system("pause");
	system("cls");
}

void DelStu() 
{
	system("cls");
	int studentnumber;
	printf("������ѧ�ţ�");
	scanf("%d", &studentnumber);
	Node1* p = g_pHead;
	Node1* beforeNode1 = g_pHead;
	bool tNum = false;
	bool tStu = false;
	while (p != NULL)
	{
		if (studentnumber == p->stu.stuNo)
		{
			if (!tNum)
			{
				printf("---------------------------------------ѧ����Ϣ------------------------------------------\n");
				printf("*\tѧ��\t*\t����\t*\t�Ա�\t*\t����\t*\tԺϵ\t*\n");
				printf("-----------------------------------------------------------------------------------------\n");
				tNum = true;
			}
			printf("*\t%d\t*\t%s\t*\t%s\t*\t%d\t*\t%s\t*\n",
				p->stu.stuNo,
				p->stu.stuName,
				p->stu.stuSex,
				p->stu.stuAge,
				p->stu.college
			);
			tStu = true;
			printf("-----------------------------------------------------------------------------------------\n");
			if (p == g_pHead) {
				g_pHead = p->pNext;
			}
			else if (p->pNext == NULL) {
				p = beforeNode1;
				p->pNext = NULL;
			}
			else {
				beforeNode1->pNext = p->pNext;
			}
			printf("ɾ���ɹ�\n\n");
		}
		beforeNode1 = p;
		p = p->pNext;
	}
	if (!tStu) {
		printf("�������\n\n");
	}
	system("pause");
	system("cls");
}

void DelCou()
{
	system("cls");
	int classNum;
	printf("������γ̺ţ�");
	scanf("%d", &classNum);
	Node2* p = g_pHead2;
	Node2* beforeNode2 = g_pHead2;
	bool tNum2 = false;
	bool tCou = false;
	while (p != NULL)
	{
		if (classNum == p->cou.cNumber)
		{
			if (!tNum2)
			{
				printf("---------------------------------------�γ���Ϣ------------------------------------------\n");
				printf("*\t�γ̺�\t*\t�γ���\t*\t���п�\t*\tѧ��\t*\n");
				printf("-----------------------------------------------------------------------------------------\n");
				tNum2 = true;
			}
			printf("\t\t\t* %ld\t\t\t%s\t\t%s\t\t%d\t\t\t*\n",
				p->cou.cNumber,
				p->cou.cName,
				p->cou.pCourse,
				p->cou.cScore
			);
			tCou = true;
			printf("-----------------------------------------------------------------------------------------\n");
			if (p == g_pHead2) {
				g_pHead2 = p->pNext;
			}
			else if (p->pNext == NULL) {
				p = beforeNode2;
				p->pNext = NULL;
			}
			else {
				beforeNode2->pNext = p->pNext;
			}
			printf("ɾ���ɹ�\n\n");
		}
		beforeNode2 = p;
		p = p->pNext;
	}
	if (!tCou) {
		printf("�������\n\n");
	}
	system("pause");
	system("cls");
}