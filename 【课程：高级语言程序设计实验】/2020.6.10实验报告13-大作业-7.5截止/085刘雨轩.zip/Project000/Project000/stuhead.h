#pragma once

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

typedef struct tagStudent 
{
	char stuName[20];
	int  stuNo;
	char stuSex[5];
	int  stuAge;
	char college[40];
}Student;

typedef struct CourseInfo
{
	long cNumber;
	char cName[20];
	char pCourse[20];
	int cScore;
}Course;

typedef struct tagNode1
{
	Student stu;			
	struct tagNode1* pNext;
}Node1;

Node1* g_pHead = NULL;

typedef struct tagNode2
{
	Course cou;
	struct tagNode2* pNext;
}Node2;

Node2* g_pHead2 = NULL;

void Menu();
void InputStu();
void InputCou();
void PrintStu();
void PrintCou();
void SaveFile();
void FindStu();
void FindCou();
void ChanStu();
void ChanCou();
void DelStu(); 
void DelCou();

#pragma once
